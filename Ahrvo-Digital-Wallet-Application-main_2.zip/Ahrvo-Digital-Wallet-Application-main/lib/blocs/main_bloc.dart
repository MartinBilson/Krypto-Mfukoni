import 'package:air_crypto/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

class MainBloc with ChangeNotifier {
  final localAuth = LocalAuthentication();

  bool hasFaceID = false;
  bool hasTouchID = false;

  Future<void> authenticate() async {
    try {
      bool didAuthenticate = await localAuth.authenticate(
        localizedReason: 'Please authenticate to show account balance',
        biometricOnly: true,
        stickyAuth: true,
      );
      console(didAuthenticate);
    } on PlatformException catch (e) {
      rethrow;
    }
  }

  Future<void> checkSupportedAuthHardware() async {
    bool canCheckBiometrics = await localAuth.canCheckBiometrics;
    if (canCheckBiometrics) {
      List<BiometricType> availableBiometrics =
          await localAuth.getAvailableBiometrics();

      if (availableBiometrics.contains(BiometricType.face)) {
        hasFaceID = true;
      } else if (availableBiometrics.contains(BiometricType.fingerprint)) {
        hasTouchID = true;
      }
      notifyListeners();
    }
  }
}
