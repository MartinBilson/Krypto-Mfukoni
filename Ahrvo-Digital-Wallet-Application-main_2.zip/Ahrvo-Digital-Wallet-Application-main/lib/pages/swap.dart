import 'dart:ui';

import 'package:air_crypto/style/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SwapScreen extends StatefulWidget {
  const SwapScreen({Key? key}) : super(key: key);
  static const routeName = '/swapScreen';

  @override
  _SwapScreenState createState() => _SwapScreenState();
}

class _SwapScreenState extends State<SwapScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: Container(
        width: 1.sw,
        height: 1.sh,
        child: Column(
          children: [
            SizedBox(
              height: 52.h,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: Navigator.of(context).pop,
                    child: SvgPicture.asset(
                      'assets/svg/arrow_left.svg',
                      height: 24.h,
                      width: 24.h,
                    ),
                  ),
                  Text(
                    'Swap',
                    style: bold,
                  ),
                  SizedBox(
                    width: 24.h,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 24.h,
            ),
            Stack(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 24.w),
                      child: Container(
                        width: double.infinity,
                        height: 116.h,
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 12.h),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'From',
                                  style: bold.copyWith(
                                    fontSize: 12.sp,
                                    color: AppColors.grayColor,
                                  ),
                                ),
                                Padding(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 16.w),
                                  child: Text(
                                    'Use Max',
                                    style: bold.copyWith(
                                      fontSize: 12.sp,
                                      color: AppColors.themeColor,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '0',
                                      style: regular.copyWith(
                                        fontSize: 34.sp,
                                        color: AppColors.textFieldHintTextColor,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 2.h,
                                    ),
                                    Text(
                                      '\$0.00',
                                      style: regular.copyWith(
                                        fontSize: 16.sp,
                                        color: AppColors.textFieldHintTextColor,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      height: 32.h,
                                      width: 32.h,
                                      decoration: const BoxDecoration(
                                        color: AppColors.lightGrayColor,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 4.w,
                                    ),
                                    Text(
                                      'BNB',
                                      style: regular.copyWith(
                                        fontSize: 16.sp,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 4.w,
                                    ),
                                    SvgPicture.asset(
                                      'assets/svg/arrow_down.svg',
                                      width: 24.h,
                                      height: 24.h,
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 16.h,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 24.w),
                      child: Container(
                        width: double.infinity,
                        height: 116.h,
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 12.h),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'To',
                              style: bold.copyWith(
                                fontSize: 12.sp,
                                color: AppColors.grayColor,
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '0',
                                      style: regular.copyWith(
                                        fontSize: 34.sp,
                                        color: AppColors.textFieldHintTextColor,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 2.h,
                                    ),
                                    Text(
                                      '\$0.00',
                                      style: regular.copyWith(
                                        fontSize: 16.sp,
                                        color: AppColors.textFieldHintTextColor,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      height: 32.h,
                                      width: 32.h,
                                      decoration: const BoxDecoration(
                                        color: AppColors.lightGrayColor,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 4.w,
                                    ),
                                    Text(
                                      'ETH',
                                      style: regular.copyWith(
                                        fontSize: 16.sp,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 4.w,
                                    ),
                                    SvgPicture.asset(
                                      'assets/svg/arrow_down.svg',
                                      width: 24.h,
                                      height: 24.h,
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Positioned(
                  top: 108.h,
                  left: 152.w,
                  child: Container(
                    width: 72.w,
                    height: 40.h,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40.r),
                      color: const Color(0xFFFEF0D7),
                    ),
                    child: Center(
                      child: SvgPicture.asset(
                        'assets/svg/transfer.svg',
                        width: 24.h,
                        height: 24.h,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const Expanded(child: SizedBox()),
            // Container(
            //   width: 295.w,
            //   height: 56.h,
            //   decoration: BoxDecoration(
            //     borderRadius: BorderRadius.circular(56.h),
            //     // color: Colors.white10,
            //   ),
            //   child: ClipRRect(
            //     borderRadius: BorderRadius.circular(56.h),
            //     child: BackdropFilter(
            //       filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            //       child: Container(
            //         color: Colors.white.withOpacity(0.10),
            //         child: Row(
            //           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //           children: [
            //             GestureDetector(
            //               onTap: () => Navigator.of(context).pushReplacement(
            //                 MaterialWithModalsPageRoute(
            //                   builder: (context) => const Home(),
            //                 ),
            //               ),
            //               child: SvgPicture.asset(
            //                 'assets/svg/wallet.svg',
            //                 width: 24.h,
            //                 height: 24.h,
            //                 fit: BoxFit.cover,
            //               ),
            //             ),
            //             // Swap
            //             GestureDetector(
            //               // onTap: () => Navigator.of(context).push(
            //               //   MaterialWithModalsPageRoute(
            //               //     builder: (context) => const SwapScreen(),
            //               //   ),
            //               // ),
            //               child: Row(
            //                 mainAxisSize: MainAxisSize.min,
            //                 children: [
            //                   SvgPicture.asset(
            //                     'assets/svg/transfer.svg',
            //                     width: 24.h,
            //                     height: 24.h,
            //                     fit: BoxFit.cover,
            //                   ),
            //                   SizedBox(
            //                     width: 2.w,
            //                   ),
            //                   Text(
            //                     'Swap',
            //                     style: regular.copyWith(
            //                       fontSize: 14.sp,
            //                       color: AppColors.themeColor,
            //                     ),
            //                   ),
            //                 ],
            //               ),
            //             ),
            //             SvgPicture.asset(
            //               'assets/svg/scan.svg',
            //               width: 24.h,
            //               height: 24.h,
            //               fit: BoxFit.cover,
            //             ),
            //             GestureDetector(
            //               onTap: () => Navigator.of(context).push(
            //                 MaterialWithModalsPageRoute(
            //                   builder: (context) => const Settings(),
            //                 ),
            //               ),
            //               child: SvgPicture.asset(
            //                 'assets/svg/settings.svg',
            //                 width: 24.h,
            //                 height: 24.h,
            //                 fit: BoxFit.cover,
            //               ),
            //             ),
            //           ],
            //         ),
            //       ),
            //     ),
            //   ),
            // ),
            SizedBox(
              height: 47.h,
            ),
          ],
        ),
      ),
    );
  }
}
