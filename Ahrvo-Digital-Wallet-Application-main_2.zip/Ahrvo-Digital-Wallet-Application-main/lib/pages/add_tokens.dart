import 'package:air_crypto/style/style.dart';
import 'package:air_crypto/widgets/input_field.dart';
import 'package:air_crypto/widgets/primary_button.dart';
import 'package:air_crypto/widgets/secondary_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AddTokens extends StatefulWidget {
  const AddTokens({Key? key}) : super(key: key);

  @override
  _AddTokensState createState() => _AddTokensState();
}

class _AddTokensState extends State<AddTokens>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final searchController = TextEditingController();
  final addressController = TextEditingController();
  final symbolsController = TextEditingController();
  final precisionController = TextEditingController();

  bool isBATselected = false;
  bool isBTCselected = false;
  bool isGBYTEselected = false;
  bool isBWKselected = false;
  bool isXBYselected = false;

  bool customTokenButtonDisabled = true;

  @override
  void initState() {
    _tabController = TabController(
      length: 2,
      vsync: this,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final width = 1.sw;
    final height = 1.sh;
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: Stack(
        children: [
          // Positioned(
          //   right: 0,
          //   top: 82.h,
          //   child: Image.asset(
          //     'assets/images/add_asset.png',
          //     height: 134.3.h,
          //     fit: BoxFit.cover,
          //   ),
          // ),
          Container(
            width: 1.sw,
            padding: EdgeInsets.symmetric(
              horizontal: 24.w,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFE0E0E0),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Text(
                  'Add Asset',
                  style: bold,
                ),
                SizedBox(
                  height: 32.h,
                ),
                TabBar(
                  labelStyle: bold.copyWith(
                    fontSize: 16.sp,
                    color: AppColors.themeColor,
                  ),
                  unselectedLabelStyle: bold.copyWith(
                    fontSize: 16.sp,
                  ),
                  controller: _tabController,
                  unselectedLabelColor: Colors.black,
                  labelColor: AppColors.themeColor,
                  indicatorSize: TabBarIndicatorSize.tab,
                  indicatorColor: AppColors.tabbarColor,
                  isScrollable: true,
                  tabs: const [
                    SizedBox(
                      child: Tab(
                        text: 'Search',
                      ),
                    ),
                    Tab(
                      child: Text(
                        'Custom Token',
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 614.h,
                  child: TabBarView(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 24.h,
                          ),
                          CustomInputField(
                            controller: searchController,
                            height: 56.h,
                            hintText: 'Search',
                            width: double.infinity,
                            inputType: InputType.name,
                            isSearch: true,
                          ),
                          SizedBox(
                            height: 24.h,
                          ),
                          Text(
                            'Select Tokens',
                            style: bold,
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          SizedBox(
                            height: 368.h,
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  renderTokenCard(
                                      'Basic Attention Token', isBATselected,
                                      () {
                                    setState(() {
                                      isBATselected = true;
                                      isBTCselected = false;
                                      isGBYTEselected = false;
                                      isBWKselected = false;
                                      isXBYselected = false;
                                    });
                                  }),
                                  SizedBox(height: 12.h),
                                  renderTokenCard(
                                      'Bitcoin (BTC)', isBTCselected, () {
                                    setState(() {
                                      isBATselected = false;
                                      isBTCselected = true;
                                      isGBYTEselected = false;
                                      isBWKselected = false;
                                      isXBYselected = false;
                                    });
                                  }),
                                  SizedBox(height: 12.h),
                                  renderTokenCard(
                                      'Byteball Bytes (GBYTE)', isGBYTEselected,
                                      () {
                                    setState(() {
                                      isBATselected = false;
                                      isBTCselected = false;
                                      isGBYTEselected = true;
                                      isBWKselected = false;
                                      isXBYselected = false;
                                    });
                                  }),
                                  SizedBox(height: 12.h),
                                  renderTokenCard(
                                      'Bulwark (BWK)', isBWKselected, () {
                                    setState(() {
                                      isBATselected = false;
                                      isBTCselected = false;
                                      isGBYTEselected = false;
                                      isBWKselected = true;
                                      isXBYselected = false;
                                    });
                                  }),
                                  SizedBox(height: 12.h),
                                  renderTokenCard(
                                      'XTRABYTES (XBY)', isXBYselected, () {
                                    setState(() {
                                      isBATselected = false;
                                      isBTCselected = false;
                                      isGBYTEselected = false;
                                      isBWKselected = false;
                                      isXBYselected = true;
                                    });
                                  }),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 10.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SecondaryButton(
                                text: 'Cancel',
                                width: 156.w,
                                height: 56.h,
                                showBorders: false,
                                onPressed: Navigator.of(context).pop,
                              ),
                              PrimaryButton(
                                text: 'Add Token',
                                width: 156.w,
                                height: 56.h,
                                disabled: !isBATselected &&
                                    !isBTCselected &&
                                    !isGBYTEselected &&
                                    !isBWKselected &&
                                    !isXBYselected,
                                greyOut: !isBATselected &&
                                    !isBTCselected &&
                                    !isGBYTEselected &&
                                    !isBWKselected &&
                                    !isXBYselected,
                                onPressed: Navigator.of(context).pop,
                              ),
                            ],
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          SizedBox(
                            height: 24.h,
                          ),
                          CustomInputField(
                            controller: addressController,
                            width: double.infinity,
                            height: 56.h,
                            inputType: InputType.name,
                            hintText: 'Token address',
                            hasNextTextField: true,
                            onChangedCallback: () {
                              if (addressController.value.text.trim().isNotEmpty &&
                                  symbolsController.value.text
                                      .trim()
                                      .isNotEmpty &&
                                  precisionController.value.text
                                      .trim()
                                      .isNotEmpty) {
                                setState(() {
                                  customTokenButtonDisabled = false;
                                });
                              } else {
                                if (!customTokenButtonDisabled) {
                                  setState(() {
                                    customTokenButtonDisabled = true;
                                  });
                                }
                              }
                            },
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          CustomInputField(
                            controller: symbolsController,
                            width: double.infinity,
                            height: 56.h,
                            inputType: InputType.name,
                            hintText: 'Token symbols',
                            hasNextTextField: true,
                            onChangedCallback: () {
                              if (addressController.value.text.trim().isNotEmpty &&
                                  symbolsController.value.text
                                      .trim()
                                      .isNotEmpty &&
                                  precisionController.value.text
                                      .trim()
                                      .isNotEmpty) {
                                setState(() {
                                  customTokenButtonDisabled = false;
                                });
                              } else {
                                if (!customTokenButtonDisabled) {
                                  setState(() {
                                    customTokenButtonDisabled = true;
                                  });
                                }
                              }
                            },
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          CustomInputField(
                            controller: precisionController,
                            width: double.infinity,
                            height: 56.h,
                            inputType: InputType.name,
                            hintText: 'Token of Precision',
                            onChangedCallback: () {
                              if (addressController.value.text.trim().isNotEmpty &&
                                  symbolsController.value.text
                                      .trim()
                                      .isNotEmpty &&
                                  precisionController.value.text
                                      .trim()
                                      .isNotEmpty) {
                                setState(() {
                                  customTokenButtonDisabled = false;
                                });
                              } else {
                                if (!customTokenButtonDisabled) {
                                  setState(() {
                                    customTokenButtonDisabled = true;
                                  });
                                }
                              }
                            },
                          ),
                          const Expanded(
                            child: SizedBox(),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SecondaryButton(
                                text: 'Cancel',
                                width: 156.w,
                                height: 56.h,
                                showBorders: false,
                                onPressed: Navigator.of(context).pop,
                              ),
                              PrimaryButton(
                                text: 'Add Token',
                                width: 156.w,
                                height: 56.h,
                                disabled: customTokenButtonDisabled,
                                greyOut: customTokenButtonDisabled,
                                onPressed: Navigator.of(context).pop,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 50.h,
                          ),
                        ],
                      )
                    ],
                    controller: _tabController,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget renderTokenCard(String title, bool isSelected, VoidCallback onTap) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 64.h,
        padding: EdgeInsets.symmetric(
          horizontal: 16.w,
          vertical: 12.h,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              height: 40.h,
              width: 40.h,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.lightGrayColor,
              ),
            ),
            SizedBox(
              width: 8.w,
            ),
            FittedBox(
              child: Text(
                title,
                style: regular,
              ),
            ),
            const Expanded(
              child: SizedBox(),
            ),
            if (isSelected)
              SvgPicture.asset(
                'assets/svg/green_tick.svg',
                height: 24.h,
                width: 24.h,
              ),
          ],
        ),
      ),
    );
  }
}
