import 'dart:ui';

import 'package:air_crypto/pages/all_settings.dart';
import 'package:air_crypto/pages/swap.dart';
import 'package:air_crypto/pages/transaction_history.dart';
import 'package:air_crypto/style/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:share_plus/share_plus.dart';

import 'home.dart';

class Settings extends StatelessWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: SizedBox(
        width: 1.sw,
        height: 1.sh,
        child: Stack(
          children: [
            // Positioned(
            //   top: 0,
            //   right: 0,
            //   child: Image.asset(
            //     'assets/images/home_top_right.png',
            //     height: 195.43.h,
            //     fit: BoxFit.cover,
            //   ),
            // ),
            // Positioned(
            //   top: 654.h,
            //   left: 4.w,
            //   child: Image.asset(
            //     'assets/images/settings.png',
            //     height: 101.1.h,
            //     fit: BoxFit.cover,
            //   ),
            // ),
            SizedBox(
              width: 1.sw,
              height: 1.sh,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 24.w),
                child: Column(
                  children: [
                    SizedBox(
                      height: 52.h,
                    ),
                    Text(
                      'Setting',
                      style: bold,
                    ),
                    SizedBox(
                      height: 24.h,
                    ),
                    renderSettingTile(
                      svgIcon: 'assets/svg/account.svg',
                      title: 'Account',
                      onPress: () {},
                    ),
                    SizedBox(
                      height: 24.h,
                    ),
                    renderSettingTile(
                      svgIcon: 'assets/svg/transaction_history.svg',
                      title: 'Transaction History',
                      onPress: () => Navigator.of(context)
                          .pushNamed(TransactionHistory.routeName),
                    ),
                    SizedBox(
                      height: 24.h,
                    ),
                    renderSettingTile(
                      svgIcon: 'assets/svg/share.svg',
                      title: 'Share Public',
                      onPress: () => Share.share(
                        'bc691db1e197914c7c0097ad6513efb6a2d68a5aad46afacf8800ffdeab91576',
                      ),
                    ),
                    SizedBox(
                      height: 24.h,
                    ),
                    renderSettingTile(
                      svgIcon: 'assets/svg/settings.svg',
                      title: 'Setting',
                      onPress: () => Navigator.of(context).push(
                        MaterialWithModalsPageRoute(
                          builder: (context) => const AllSettings(),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 24.h,
                    ),
                    renderSettingTile(
                      svgIcon: 'assets/svg/get_help.svg',
                      title: 'Get Help',
                      onPress: () {},
                    ),
                    SizedBox(
                      height: 24.h,
                    ),
                    renderSettingTile(
                      svgIcon: 'assets/svg/send_feedback.svg',
                      title: 'Send Feedback',
                      onPress: () {},
                    ),
                    SizedBox(
                      height: 56.h,
                    ),
                    renderSettingTile(
                      svgIcon: 'assets/svg/log_out.svg',
                      title: 'Log out',
                      onPress: () {},
                    ),
                    const Expanded(child: SizedBox()),
                    Container(
                      width: 295.w,
                      height: 56.h,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(56.h),
                        // color: Colors.white10,
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(56.h),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                          child: Container(
                            color: Colors.white.withOpacity(0.10),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                GestureDetector(
                                  onTap: () =>
                                      Navigator.of(context).pushReplacement(
                                    MaterialWithModalsPageRoute(
                                      builder: (context) => const Home(),
                                    ),
                                  ),
                                  child: SvgPicture.asset(
                                    'assets/svg/wallet.svg',
                                    width: 24.h,
                                    height: 24.h,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                // Swap
                                GestureDetector(
                                  onTap: () => Navigator.of(context).push(
                                    MaterialWithModalsPageRoute(
                                      builder: (context) => const SwapScreen(),
                                    ),
                                  ),
                                  child: SvgPicture.asset(
                                    'assets/svg/transfer.svg',
                                    width: 24.h,
                                    height: 24.h,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SvgPicture.asset(
                                  'assets/svg/scan.svg',
                                  width: 24.h,
                                  height: 24.h,
                                  fit: BoxFit.cover,
                                ),
                                GestureDetector(
                                  // onTap: () => Navigator.of(context).push(
                                  //   MaterialWithModalsPageRoute(
                                  //     builder: (context) => const Settings(),
                                  //   ),
                                  // ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SvgPicture.asset(
                                        'assets/svg/settings.svg',
                                        width: 24.h,
                                        height: 24.h,
                                        fit: BoxFit.cover,
                                      ),
                                      SizedBox(
                                        width: 2.w,
                                      ),
                                      Text(
                                        'Setting',
                                        style: regular.copyWith(
                                          fontSize: 14.sp,
                                          color: AppColors.themeColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 34.h,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget renderSettingTile({
    required String title,
    required String svgIcon,
    required VoidCallback onPress,
  }) {
    return GestureDetector(
      onTap: onPress,
      child: Container(
        width: double.infinity,
        height: 60.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 16.h),
              color: Colors.white.withOpacity(0.10),
              child: Row(
                children: [
                  SvgPicture.asset(
                    svgIcon,
                    height: 24.h,
                    width: 24.h,
                  ),
                  SizedBox(
                    width: 8.w,
                  ),
                  Text(
                    title,
                    style: regular,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
