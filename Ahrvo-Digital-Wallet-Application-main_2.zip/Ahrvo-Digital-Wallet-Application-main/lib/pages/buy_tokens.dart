import 'package:air_crypto/style/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BuyTokens extends StatelessWidget {
  const BuyTokens({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: Stack(
        children: [
          // Positioned(
          //   top: 165.h,
          //   right: -75.w,
          //   child: Image.asset(
          //     'assets/images/blur_pyramid.png',
          //     width: 173.08.w,
          //     fit: BoxFit.cover,
          //   ),
          // ),
          // Positioned(
          //   top: 410.h,
          //   left: -50.w,
          //   child: Image.asset(
          //     'assets/images/blur_cube.png',
          //     width: 114.2.w,
          //     fit: BoxFit.cover,
          //   ),
          // ),
          Container(
            width: 1.sw,
            padding: EdgeInsets.symmetric(
              horizontal: 24.w,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFE0E0E0),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Text(
                  'How do you want to make\nyour purchase?',
                  style: bold,
                ),
                SizedBox(
                  height: 32.h,
                ),
                Container(
                  width: double.infinity,
                  padding:
                      EdgeInsets.symmetric(horizontal: 24.w, vertical: 24.5.h),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Apple Pay via',
                        style: bold,
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '1 - 2 minutes\nMax \$450 weekly\nRequires debit card',
                            style: regular.copyWith(
                              fontSize: 14.sp,
                              color: AppColors.grayColor,
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    '🇺🇸 U.S. Only',
                                    style: regular.copyWith(
                                      fontSize: 14.sp,
                                      color: AppColors.grayColor,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10.w,
                                  ),
                                  Icon(
                                    Icons.info_outline,
                                    color: AppColors.grayColor,
                                    size: 16.h,
                                  ),
                                ],
                              ),
                              Text(
                                'Some states\nexcluded',
                                textAlign: TextAlign.end,
                                style: regular.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Container(
                  width: double.infinity,
                  padding:
                      EdgeInsets.symmetric(horizontal: 24.w, vertical: 24.5.h),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Bank transfer or\ndebit card',
                        style: bold,
                      ),
                      SizedBox(
                        height: 4.h,
                      ),
                      Text(
                        'Requires registration',
                        style: bold.copyWith(
                          fontSize: 14.sp,
                          color: AppColors.grayColor,
                        ),
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            'Option and fees vary\nbased on location',
                            style: regular.copyWith(
                              fontSize: 14.sp,
                              color: AppColors.grayColor,
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '59 Countries',
                                style: regular.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              SizedBox(
                                width: 10.w,
                              ),
                              Icon(
                                Icons.info_outline,
                                color: AppColors.grayColor,
                                size: 16.h,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
