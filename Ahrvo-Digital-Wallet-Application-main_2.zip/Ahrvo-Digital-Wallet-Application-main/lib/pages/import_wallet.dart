import 'package:air_crypto/blocs/main_bloc.dart';
import 'package:air_crypto/pages/home.dart';
import 'package:air_crypto/style/style.dart';
import 'package:air_crypto/widgets/input_field.dart';
import 'package:air_crypto/widgets/primary_button.dart';
import 'package:air_crypto/widgets/switch.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:password_strength/password_strength.dart';
import 'package:provider/provider.dart';

class ImportWallet extends StatefulWidget {
  const ImportWallet({Key? key}) : super(key: key);
  static const routeName = '/importWallet';

  @override
  _ImportWalletState createState() => _ImportWalletState();
}

class _ImportWalletState extends State<ImportWallet> {
  final seedPhraseController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  bool signInWithAuthHardware = true;
  bool enteredSeedPhrase = false;
  bool enteredNewPassword = false;
  bool enteredConfirmPassword = false;

  bool buttonEnabled = false;
  bool hasPasswordError = false;
  bool hasConfirmPasswordError = false;
  double? newPasswordStrength;

  void checkButton() {
    if (passwordController.value.text.isNotEmpty &&
        confirmPasswordController.value.text.isNotEmpty &&
        !hasConfirmPasswordError &&
        !hasPasswordError &&
        seedPhraseController.value.text.isNotEmpty) {
      setState(() {
        buttonEnabled = true;
      });
    } else {
      setState(() {
        buttonEnabled = false;
      });
    }
  }

  void validatePassword(String pass) {
    newPasswordStrength = estimatePasswordStrength(pass);
    setState(() {
      if (pass.isEmpty) {
        hasPasswordError = true;
      } else if (pass.length < 8) {
        hasPasswordError = true;
      } else {
        hasPasswordError = false;
      }
    });
    checkButton();
  }

  void validateConfirmPassword(String pass) {
    setState(() {
      if (pass != passwordController.value.text) {
        hasConfirmPasswordError = true;
      } else {
        hasConfirmPasswordError = false;
      }
    });
    checkButton();
  }

  @override
  Widget build(BuildContext context) {
    final mb = context.read<MainBloc>();
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        width: 1.sw,
        padding: EdgeInsets.symmetric(horizontal: 24.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 8.h,
            ),
            Center(
              child: Container(
                height: 6.h,
                width: 48.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6.r),
                  color: const Color(0xFFE0E0E0),
                ),
              ),
            ),
            SizedBox(
              height: 32.h,
            ),
            Text(
              "Import From Seed",
              style: bold.copyWith(fontSize: 18.sp),
            ),
            SizedBox(
              height: 24.h,
            ),
            CustomInputField(
              controller: seedPhraseController,
              width: 1.sw - (2 * 24.w),
              height: 56.h,
              hintText: 'Seed phrase',
              showScanIcon: true,
              hasNextTextField: true,
              onChangedCallback: checkButton,
            ),
            SizedBox(
              height: 16.h,
            ),
            CustomInputField(
              hintText: 'New password',
              height: 56.h,
              width: double.infinity,
              controller: passwordController,
              hasNextTextField: true,
              onEditingComplete: validatePassword,
              onChangedCallback: () => validatePassword(
                passwordController.value.text,
              ),
              hasError: hasPasswordError,
            ),
            SizedBox(
              height: 4.h,
            ),
            Row(
              children: [
                SizedBox(
                  width: 16.w,
                ),
                Text.rich(
                  TextSpan(
                    text: 'Password strength: ',
                    style: regular.copyWith(
                      color: AppColors.textFieldBottomTextColor,
                      fontSize: 12.sp,
                    ),
                    children: newPasswordStrength != null
                        ? [
                            TextSpan(
                              text: newPasswordStrength! < 0.3
                                  ? 'Weak'
                                  : newPasswordStrength! < 0.7
                                      ? 'Moderate'
                                      : 'Good',
                              style: regular.copyWith(
                                color: newPasswordStrength! < 0.3
                                    ? AppColors.errorColor
                                    : newPasswordStrength! < 0.7
                                        ? Colors.amber[700]
                                        : AppColors.greenColor,
                                fontSize: 12.sp,
                              ),
                            ),
                          ]
                        : null,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 16.h,
            ),
            CustomInputField(
              hintText: 'Confirm password',
              height: 56.h,
              width: double.infinity,
              controller: confirmPasswordController,
              onEditingComplete: validateConfirmPassword,
              onChangedCallback: () => validateConfirmPassword(
                confirmPasswordController.value.text,
              ),
              hasError: hasConfirmPasswordError,
            ),
            SizedBox(
              height: 4.h,
            ),
            Padding(
              padding: EdgeInsets.only(left: 16.w),
              child: Text(
                'Must be at least 8 characters',
                style: regular.copyWith(
                  fontSize: 12.sp,
                  color: hasPasswordError
                      ? AppColors.errorColor
                      : AppColors.textFieldBottomTextColor,
                ),
              ),
            ),
            if (hasConfirmPasswordError)
              Padding(
                padding: EdgeInsets.only(left: 16.w),
                child: Text(
                  'Passwords don\'t match',
                  style: regular.copyWith(
                    fontSize: 12.sp,
                    color: AppColors.errorColor,
                  ),
                ),
              ),
            SizedBox(
              height: 16.h,
            ),
            if (mb.hasFaceID || mb.hasTouchID)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    // 'Sign in with ${Platform.isIOS ? mb.hasFaceID ? 'Face ID' : mb.hasTouchID ? 'Touch ID' : '' : mb.hasFaceID ? 'Face ID' : mb.hasTouchID ? 'Fingerprint' : ''}?',
                    'Sign in with Biometrics?',
                    style: regular.copyWith(
                      fontSize: 18.sp,
                    ),
                  ),
                  CustomSwitch(
                    value: signInWithAuthHardware,
                    activeColor: AppColors.themeColor,
                    onChanged: (value) {
                      setState(() {
                        signInWithAuthHardware = value;
                      });
                    },
                  ),
                ],
              ),
            const Expanded(child: SizedBox()),
            FittedBox(
              child: Text.rich(
                TextSpan(
                  text: 'By proceeding, you agree to these',
                  style: regular.copyWith(
                    fontSize: 12.sp,
                    color: AppColors.grayColor,
                  ),
                  children: [
                    TextSpan(
                      text: 'Terms and conditions.',
                      style: regular.copyWith(
                        fontSize: 12.sp,
                        color: AppColors.blueHyperlinkColor,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 32.h,
            ),
            PrimaryButton(
              text: 'Import',
              width: 1.sw - (2 * 24.w),
              height: 56.h,
              disabled: !buttonEnabled,
              greyOut: !buttonEnabled,
              onPressed: () {
                Navigator.of(context)
                    .pushNamedAndRemoveUntil(Home.routeName, (route) => false);
              },
            ),
            SizedBox(
              height: 50.h,
            ),
          ],
        ),
      ),
    );
  }
}
