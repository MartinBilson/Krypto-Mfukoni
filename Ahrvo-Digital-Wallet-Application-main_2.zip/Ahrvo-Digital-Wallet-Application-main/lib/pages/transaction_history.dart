import 'package:air_crypto/pages/token_details.dart';
import 'package:air_crypto/style/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class TransactionHistory extends StatelessWidget {
  const TransactionHistory({Key? key}) : super(key: key);
  static const routeName = '/transactionHistory';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: SizedBox(
        width: 1.sw,
        height: 1.sh,
        child: Column(
          children: [
            SizedBox(
              height: 52.h,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: Navigator.of(context).pop,
                    child: SvgPicture.asset(
                      'assets/svg/arrow_left.svg',
                      height: 24.h,
                      width: 24.h,
                    ),
                  ),
                  Text(
                    'Transactions',
                    style: bold,
                  ),
                  SizedBox(
                    width: 24.h,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 24.h,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const TransactionCard(
                    cryptoAmmount: '2.8 BNB',
                    cryptoName: 'BNB',
                    dollarAmmount: '\$647.22',
                    transactionStatus: TransactionStatus.pending,
                    transactionType: TransactionType.received,
                    dateAndTime: 'Mar 4 at 10:04 AM',
                  ),
                  SizedBox(
                    height: 12.h,
                  ),
                  const TransactionCard(
                    cryptoAmmount: '1.334 BNB',
                    cryptoName: 'BNB',
                    dollarAmmount: '\$315.34426',
                    transactionStatus: TransactionStatus.failed,
                    transactionType: TransactionType.sent,
                    dateAndTime: '#1 Mar 3 at 12:08 AM',
                  ),
                  SizedBox(
                    height: 12.h,
                  ),
                  const TransactionCard(
                    cryptoAmmount: '2.891 BNB',
                    cryptoName: 'BNB',
                    dollarAmmount: '\$683403.49',
                    transactionStatus: TransactionStatus.confirmed,
                    transactionType: TransactionType.sent,
                    dateAndTime: '#1 Mar 3 at 12:08 AM',
                  ),
                  SizedBox(
                    height: 12.h,
                  ),
                  const TransactionCard(
                    cryptoAmmount: '0.5637 BNB',
                    cryptoName: 'BNB',
                    dollarAmmount: '\$133,2530',
                    transactionStatus: TransactionStatus.confirmed,
                    transactionType: TransactionType.received,
                    dateAndTime: '#1 Mar 3 at 12:08 AM',
                  ),
                  SizedBox(
                    height: 12.h,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
