import 'dart:ui';

import 'package:air_crypto/pages/add_tokens.dart';
import 'package:air_crypto/pages/send_tokens.dart';
import 'package:air_crypto/pages/settings.dart';
import 'package:air_crypto/pages/swap.dart';
import 'package:air_crypto/pages/token_details.dart';
import 'package:air_crypto/style/style.dart';
import 'package:air_crypto/utils/utils.dart';
import 'package:air_crypto/widgets/input_field.dart';
import 'package:air_crypto/widgets/primary_button.dart';
import 'package:air_crypto/widgets/secondary_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);
  static const routeName = '/home';

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(
      length: 2,
      vsync: this,
    );
    super.initState();
  }

  Future<void> showNetworks() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          Container(
            width: 1.sw,
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFD6D6D6),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Text(
                  'Networks',
                  style: bold.copyWith(fontSize: 18.sp),
                ),
                SizedBox(
                  height: 16.56.h,
                ),
                const NetworkTile(
                  title: 'Ethereum Main Network',
                  isSelected: true,
                  dotColor: AppColors.themeColor,
                ),
                SizedBox(
                  height: 32.h,
                ),
                Text(
                  'Other Networks',
                  style: regular.copyWith(fontSize: 18.sp),
                ),
                SizedBox(
                  height: 32.h,
                ),
                const NetworkTile(
                  title: 'Ropsten Test Network',
                  isSelected: false,
                  dotColor: AppColors.blueHyperlinkColor,
                ),
                SizedBox(
                  height: 32.h,
                ),
                const NetworkTile(
                  title: 'Test Network',
                  isSelected: false,
                  dotColor: AppColors.greenColor,
                ),
                SizedBox(
                  height: 32.h,
                ),
                const NetworkTile(
                  title: 'Rinkeby Test Network',
                  isSelected: false,
                  dotColor: AppColors.yellowColor,
                ),
                SizedBox(
                  height: 32.h,
                ),
                const NetworkTile(
                  title: 'Goeli Test Network',
                  isSelected: false,
                  dotColor: AppColors.errorColor,
                ),
                SizedBox(
                  height: 61.44.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showAccounts() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          Container(
            width: 1.sw,
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFD6D6D6),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Text(
                  'Account',
                  style: bold.copyWith(fontSize: 18.sp),
                ),
                SizedBox(
                  height: 24.h,
                ),
                const AccountTile(
                  emojiBgColor: Color(0xFFFEF0D7),
                  emoji: '🐼',
                  title: 'Queen Bee',
                  isSelected: true,
                ),
                SizedBox(
                  height: 32.h,
                ),
                const AccountTile(
                  emojiBgColor: Color(0xFFFFEBDD),
                  emoji: '🐋',
                  title: 'Lalimo Rubik',
                  isSelected: false,
                ),
                SizedBox(
                  height: 32.h,
                ),
                const AccountTile(
                  emojiBgColor: Color(0xFFEBEBEB),
                  emoji: '🐇',
                  title: 'Neil momo',
                  isSelected: false,
                ),
                SizedBox(
                  height: 24.h,
                ),
                SecondaryButton(
                  text: 'Create New Account',
                  width: double.infinity,
                  height: 56.h,
                  onPressed: () {
                    Navigator.of(context).pop();
                    showCupertinoModalBottomSheet(
                      context: context,
                      builder: (ctx) => const CreateAccount(),
                    );
                  },
                ),
                SizedBox(
                  height: 16.h,
                ),
                PrimaryButton(
                  text: 'Import Account',
                  width: double.infinity,
                  height: 56.h,
                  onPressed: () {
                    Navigator.of(context).pop();
                    showCupertinoModalBottomSheet(
                      context: context,
                      builder: (ctx) => const ImportAccount(),
                    );
                  },
                ),
                SizedBox(
                  height: 50.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final height = 1.sh;
    final width = 1.sw;

    return Scaffold(
      body: SizedBox(
        height: height,
        width: width,
        child: Stack(
          children: [
            // Positioned(
            //   top: 0,
            //   right: -4.w,
            //   child: Image.asset(
            //     'assets/images/home_top_right.png',
            //     width: 151.w,
            //     height: 184.h,
            //   ),
            // ),
            SizedBox(
              height: height,
              width: width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 104.h * 0.6,
                  ),
                  Center(
                    child: Padding(
                      // padding: EdgeInsets.only(left: 24.w),
                      padding: EdgeInsets.zero,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        // crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTap: showAccounts,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  height: 40.h,
                                  width: 40.h,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: AppColors.pandaBgColor,
                                  ),
                                  child: Center(
                                    child: Text(
                                      '🐼',
                                      style: bold.copyWith(
                                        fontSize: 16.sp,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 12.w,
                                ),
                                Text(
                                  'Queen Bee',
                                  style: bold.copyWith(
                                    fontSize: 12.sp,
                                    color: AppColors.themeColor,
                                  ),
                                ),
                                SizedBox(
                                  width: 8.w,
                                ),
                                SvgPicture.asset(
                                  'assets/svg/arrow_down.svg',
                                  width: 24.h,
                                  height: 24.h,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTap: showNetworks,
                            child: Text(
                              '4.8729 ETH',
                              style: regular.copyWith(
                                fontSize: 34.sp,
                                color: AppColors.textColor,
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 8.h,
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '\$ 8,391.14',
                                style: regular.copyWith(
                                  fontSize: 20.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              SizedBox(
                                width: 16.w,
                              ),
                              SvgPicture.asset(
                                'assets/svg/green_arrow_up_tilted.svg',
                                height: 16.h,
                                width: 16.h,
                              ),
                              SizedBox(
                                width: 4.w,
                              ),
                              Text(
                                '9.97%',
                                style: regular.copyWith(
                                  fontSize: 20.sp,
                                  color: AppColors.greenColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        GestureDetector(
                          onTap: () => showCupertinoModalBottomSheet(
                            context: context,
                            builder: (context) => const SendTokens(),
                          ).then((value) {
                            console('Back');
                            if (value != null && value) {
                              showTokenSubmitted(context);
                            }
                          }),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SvgPicture.asset(
                                'assets/svg/send.svg',
                                width: 40.h,
                                height: 40.h,
                              ),
                              Text(
                                'Send',
                                style: bold.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.textColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => showReceive(context),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SvgPicture.asset(
                                'assets/svg/receive.svg',
                                width: 40.h,
                                height: 40.h,
                              ),
                              Text(
                                'Receive',
                                style: bold.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.textColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.of(context).pushNamed(SwapScreen
                              .routeName), //  showCupertinoModalBottomSheet(
                          //   context: context,
                          //   builder: (context) => const BuyTokens(),
                          // ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SvgPicture.asset(
                                'assets/svg/buy.svg',
                                width: 40.h,
                                height: 40.h,
                              ),
                              Text(
                                'Buy',
                                style: bold.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.textColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 55.w),
                    child: TabBar(
                      controller: _tabController,
                      unselectedLabelColor: Colors.black,
                      labelColor: Colors.red,
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicatorColor: AppColors.tabbarColor,
                      tabs: [
                        Tab(
                          child: Text(
                            'Tokens',
                            style: bold.copyWith(
                              fontSize: 18.sp,
                            ),
                          ),
                        ),
                        Tab(
                          child: FittedBox(
                            child: Text(
                              'Collectibles',
                              style: bold.copyWith(
                                fontSize: 18.sp,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  SizedBox(
                    height: 390.h,
                    child: ListView(
                      physics: const BouncingScrollPhysics(),
                      padding: EdgeInsets.symmetric(horizontal: 24.w),
                      children: [
                        const Token(
                          name: 'Ethereum',
                          priceInDollar: '\$ 1,722.2',
                          crypto: '2.5123 ETH',
                          upPercent: '4.06%',
                        ),
                        SizedBox(
                          height: 12.h,
                        ),
                        const Token(
                          name: 'Ethereum',
                          priceInDollar: '\$ 1,722.2',
                          crypto: '2.5123 ETH',
                          upPercent: '4.06%',
                        ),
                        SizedBox(
                          height: 12.h,
                        ),
                        const Token(
                          name: 'Binance',
                          priceInDollar: '\$ 236.39',
                          crypto: '11.4188 BNB',
                          upPercent: '3.38%',
                        ),
                        SizedBox(
                          height: 12.h,
                        ),
                        const Token(
                          name: 'Neo',
                          priceInDollar: '\$ 38.91',
                          crypto: '28.9371 NEO',
                          upPercent: '0.56%',
                        ),
                        SizedBox(
                          height: 12.h,
                        ),
                        const Token(
                          name: 'Litecoin',
                          priceInDollar: '\$ 188.39',
                          crypto: '1.3083 LTC',
                          upPercent: '1.97%',
                        ),
                        SizedBox(
                          height: 160.h,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              bottom: 34.h,
              left: (1.sw - 295.w) / 2,
              child: Container(
                width: 295.w,
                height: 56.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(56.h),
                  // color: Colors.white10,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(56.h),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                    child: Container(
                      color: Colors.white.withOpacity(0.10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SvgPicture.asset(
                                'assets/svg/wallet.svg',
                                width: 24.h,
                                height: 24.h,
                                fit: BoxFit.cover,
                              ),
                              SizedBox(
                                width: 2.w,
                              ),
                              Text(
                                'Wallet',
                                style: regular.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.themeColor,
                                ),
                              )
                            ],
                          ),
                          // Swap
                          GestureDetector(
                            // onTap: () => Navigator.of(context).pushReplacement(
                            //   MaterialWithModalsPageRoute(
                            //     builder: (context) => const SwapScreen(),
                            //   ),
                            // ),
                            child: SvgPicture.asset(
                              'assets/svg/globe.svg',
                              width: 22.h,
                              height: 22.h,
                              fit: BoxFit.cover,
                              color: AppColors.darkGrayColor,
                            ),
                          ),
                          SvgPicture.asset(
                            'assets/svg/scan.svg',
                            width: 24.h,
                            height: 24.h,
                            fit: BoxFit.cover,
                          ),
                          GestureDetector(
                            onTap: () => Navigator.of(context).pushReplacement(
                              MaterialWithModalsPageRoute(
                                builder: (context) => const Settings(),
                              ),
                            ),
                            child: SvgPicture.asset(
                              'assets/svg/settings.svg',
                              width: 24.h,
                              height: 24.h,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 106.h,
              left: 109.w,
              child: PrimaryButton(
                height: 56.h,
                width: 157.w,
                onPressed: () => showCupertinoModalBottomSheet(
                  context: context,
                  builder: (context) => const AddTokens(),
                ),
                text: 'Add Tokens',
                icon: SvgPicture.asset(
                  'assets/svg/plus.svg',
                  width: 24.h,
                  height: 24.h,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> showTokenSubmitted(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          SizedBox(
            width: 1.sw,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFD6D6D6),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Text(
                    'Send BNB',
                    style: bold.copyWith(fontSize: 18.sp),
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Center(
                  child: SvgPicture.asset(
                    'assets/svg/submitted.svg',
                    width: 64.h,
                    height: 64.h,
                    fit: BoxFit.cover,
                  ),
                ),
                Center(
                  child: Text(
                    'Submitted',
                    style: bold.copyWith(
                      fontSize: 18.sp,
                      color: AppColors.textColor,
                    ),
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 24.h),
                    width: 1.sw - (2 * 24.w),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: Colors.white,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Amount',
                                style: regular,
                              ),
                              Text(
                                '2.3686 BNB',
                                style: regular,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 4.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Network fee',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                '0.972 BNB',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        const Divider(
                          color: Color(0xFFDADADA),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'From',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                'bc1q87...34pm',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'To',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                '3g78pk...sd42',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Date',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                'Feb 28 at 2:03 PM',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Nonce',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                '#0',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        const Divider(
                          color: Color(0xFFDADADA),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Total Amount',
                                style: regular,
                              ),
                              Text(
                                '3.3406 BNB',
                                style: bold,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                '\$ 880.05',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 42.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SecondaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: () => showCancel(context),
                        showBorders: false,
                        text: 'Cancel',
                      ),
                      PrimaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: () => showSpeedUp(context),
                        text: 'Speed Up',
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 50.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showSpeedUp(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          SizedBox(
            width: 1.sw,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 8.h,
                  ),
                  Center(
                    child: Container(
                      height: 6.h,
                      width: 48.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6.r),
                        color: const Color(0xFFD6D6D6),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 32.h,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: Text(
                      'Attempt to speed up?',
                      style: bold.copyWith(fontSize: 18.sp),
                    ),
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Gas Speed Up Fee',
                        style: regular,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 4.h),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30.r),
                        ),
                        child: Center(
                          child: Text(
                            '<0.00001 ETH',
                            style: bold.copyWith(
                              fontSize: 14.sp,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Text(
                    'Submitting this attempt does not guarantee your original transaction will be accelerated. If the speed up attempt is successful, you will be charged the transaction fee above.',
                    style: regular.copyWith(
                      fontSize: 16.sp,
                      color: AppColors.grayColor,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SecondaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: Navigator.of(context).pop,
                        showBorders: false,
                        text: 'Nevermind',
                      ),
                      PrimaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: Navigator.of(context).pop,
                        text: 'Yes, Let\'s Try',
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 50.h,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showCancel(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          SizedBox(
            width: 1.sw,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 8.h,
                  ),
                  Center(
                    child: Container(
                      height: 6.h,
                      width: 48.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6.r),
                        color: const Color(0xFFD6D6D6),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 32.h,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: Text(
                      'Attempt to cancel?',
                      style: bold.copyWith(fontSize: 18.sp),
                    ),
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Gas Cancellation Fee',
                        style: regular,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 4.h),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30.r),
                        ),
                        child: Center(
                          child: Text(
                            '<0.00001 ETH',
                            style: bold.copyWith(
                              fontSize: 14.sp,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Text(
                    'Submitting this attempt does not guarantee your original transaction will be cancelled. If the cancellation attempt is successful, you will be charged the transaction fee above.',
                    style: regular.copyWith(
                      fontSize: 16.sp,
                      color: AppColors.grayColor,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SecondaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: Navigator.of(context).pop,
                        showBorders: false,
                        text: 'Nevermind',
                      ),
                      PrimaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: Navigator.of(context).pop,
                        text: 'Yes, Let\'s Try',
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 50.h,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showReceive(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          SizedBox(
            width: 1.sw,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 8.h,
                  ),
                  Center(
                    child: Container(
                      height: 6.h,
                      width: 48.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6.r),
                        color: const Color(0xFFD6D6D6),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 32.h,
                  ),
                  Text(
                    'Received BNB',
                    style: bold.copyWith(fontSize: 18.sp),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: Container(
                      height: 279.h,
                      width: 279.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: AppColors.grayColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Center(
                    child: Text(
                      'Scan address to Receive payment',
                      style: regular.copyWith(
                        fontSize: 16.sp,
                        color: AppColors.grayColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 16.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SecondaryButton(
                        height: 56.h,
                        width: 155.w,
                        onPressed: Navigator.of(context).pop,
                        text: 'bc1q87...34pm',
                        textStyle: bold.copyWith(
                          fontSize: 14.sp,
                          color: AppColors.themeColor,
                        ),
                        icon: SvgPicture.asset(
                          'assets/svg/copy.svg',
                          width: 24.h,
                          height: 24.h,
                        ),
                      ),
                      SecondaryButton(
                        height: 56.h,
                        width: 155.w,
                        onPressed: Navigator.of(context).pop,
                        text: 'Share',
                        textStyle: bold.copyWith(
                          fontSize: 14.sp,
                          color: AppColors.themeColor,
                        ),
                        icon: SvgPicture.asset(
                          'assets/svg/share.svg',
                          width: 24.h,
                          height: 24.h,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  PrimaryButton(
                    icon: SvgPicture.asset(
                      'assets/svg/arrow_up.svg',
                      width: 24.h,
                      height: 24.h,
                    ),
                    text: 'Send Link',
                    width: double.infinity,
                    height: 56.h,
                    onPressed: () {},
                  ),
                  SizedBox(
                    height: 50.h,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AccountTile extends StatelessWidget {
  const AccountTile({
    Key? key,
    required this.emojiBgColor,
    required this.emoji,
    required this.title,
    required this.isSelected,
  }) : super(key: key);

  final Color emojiBgColor;
  final String emoji;
  final String title;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 40.h,
          height: 40.h,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: emojiBgColor,
          ),
          child: Center(
            child: Text(
              emoji,
              style: bold.copyWith(
                fontSize: 16.sp,
              ),
            ),
          ),
        ),
        SizedBox(
          width: 8.w,
        ),
        Text(
          title,
          style: regular.copyWith(
            fontSize: 16.sp,
            color: AppColors.grayColor,
          ),
        ),
        const Expanded(child: SizedBox()),
        if (isSelected)
          SvgPicture.asset(
            'assets/svg/green_tick.svg',
            width: 24.h,
            height: 24.h,
          ),
      ],
    );
  }
}

class NetworkTile extends StatelessWidget {
  const NetworkTile({
    Key? key,
    required this.dotColor,
    required this.title,
    required this.isSelected,
  }) : super(key: key);

  final Color dotColor;
  final String title;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 9.w),
      child: Row(
        children: [
          Container(
            width: 6.h,
            height: 6.h,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: dotColor,
            ),
          ),
          SizedBox(
            width: 17.w,
          ),
          Text(
            title,
            style: regular.copyWith(
              fontSize: 16.sp,
              color: AppColors.grayColor,
            ),
          ),
          const Expanded(child: SizedBox()),
          if (isSelected)
            SvgPicture.asset(
              'assets/svg/green_tick.svg',
              width: 24.h,
              height: 24.h,
            ),
        ],
      ),
    );
  }
}

class Token extends StatelessWidget {
  const Token({
    Key? key,
    required this.name,
    required this.priceInDollar,
    required this.crypto,
    required this.upPercent,
    // this.onPress,
  }) : super(key: key);

  final String name;
  final String priceInDollar;
  final String crypto;
  final String upPercent;
  // final VoidCallback? onPress;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        Navigator.of(context).push(
          MaterialWithModalsPageRoute(
            builder: (context) => TokenDetails(
              cryptoAmmount: crypto,
              cryptoName: crypto.split(' ').last,
              dollarAmmount: priceInDollar,
              upPercent: upPercent,
            ),
          ),
        );
      },
      child: Container(
        height: 78.h,
        width: 1.sw - (2 * 24.w),
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              width: 40.h,
              height: 40.h,
              decoration: const BoxDecoration(
                color: AppColors.lightGrayColor,
                shape: BoxShape.circle,
              ),
            ),
            SizedBox(
              width: 8.w,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 12,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          name,
                          style: regular.copyWith(
                            fontSize: 18.sp,
                            color: AppColors.textColor,
                          ),
                        ),
                        Text(
                          priceInDollar,
                          style: regular.copyWith(
                            fontSize: 16.sp,
                            color: AppColors.grayColor,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          crypto,
                          style: regular.copyWith(
                            fontSize: 18.sp,
                            color: AppColors.textColor,
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SvgPicture.asset(
                              'assets/svg/green_arrow_up_tilted.svg',
                              height: 24.h,
                              width: 24.h,
                            ),
                            SizedBox(
                              width: 8.w,
                            ),
                            Text(
                              upPercent,
                              style: regular.copyWith(
                                fontSize: 20.sp,
                                color: AppColors.greenColor,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CreateAccount extends StatefulWidget {
  const CreateAccount({Key? key}) : super(key: key);

  @override
  _CreateAccountState createState() => _CreateAccountState();
}

class _CreateAccountState extends State<CreateAccount> {
  final nameController = TextEditingController();
  bool enteredName = false;
  bool buttonEnabled = false;

  void checkButton() {
    if (nameController.value.text.trim().isNotEmpty) {
      setState(() {
        buttonEnabled = true;
      });
    } else {
      setState(() {
        buttonEnabled = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: 1.sw,
        padding: EdgeInsets.symmetric(horizontal: 24.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 8.h,
            ),
            Center(
              child: Container(
                height: 6.h,
                width: 48.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6.r),
                  color: const Color(0xFFE0E0E0),
                ),
              ),
            ),
            SizedBox(
              height: 32.h,
            ),
            Text(
              'Create An Account',
              style: bold.copyWith(fontSize: 18.sp),
            ),
            SizedBox(
              height: 16.h,
            ),
            CustomInputField(
              hintText: 'Account Name',
              height: 56.h,
              inputType: InputType.name,
              capitalizeSentences: true,
              width: double.infinity,
              controller: nameController,
              onEditingComplete: (_) => checkButton,
              onChangedCallback: checkButton,
            ),
            const Expanded(child: SizedBox()),
            PrimaryButton(
              text: 'Create An Account',
              width: 1.sw - (2 * 24.w),
              height: 56.h,
              disabled: !buttonEnabled,
              greyOut: !buttonEnabled,
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            SizedBox(
              height:
                  MediaQuery.of(context).viewInsets.bottom > 100 ? 16.h : 50.h,
            ),
          ],
        ),
      ),
    );
  }
}

class ImportAccount extends StatefulWidget {
  const ImportAccount({Key? key}) : super(key: key);

  @override
  _ImportAccountState createState() => _ImportAccountState();
}

class _ImportAccountState extends State<ImportAccount> {
  final keyController = TextEditingController();
  bool enteredKey = false;
  bool buttonEnabled = false;

  void checkButton() {
    if (keyController.value.text.trim().isNotEmpty) {
      setState(() {
        buttonEnabled = true;
      });
    } else {
      setState(() {
        buttonEnabled = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: 1.sw,
        padding: EdgeInsets.symmetric(horizontal: 24.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 8.h,
            ),
            Center(
              child: Container(
                height: 6.h,
                width: 48.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6.r),
                  color: const Color(0xFFE0E0E0),
                ),
              ),
            ),
            SizedBox(
              height: 32.h,
            ),
            Text(
              'Import An Account',
              style: bold.copyWith(fontSize: 18.sp),
            ),
            SizedBox(
              height: 16.h,
            ),
            Text(
              'Imported accounts are viewable in your wallet but are not recorverable with your Ahrvo seed phrase.\n\nLearn more about imported accounts here.',
              style: regular.copyWith(
                fontSize: 16.sp,
                color: AppColors.grayColor,
              ),
            ),
            SizedBox(
              height: 40.h,
            ),
            Text(
              'Paste Your Private Key String',
              style: bold.copyWith(fontSize: 18.sp),
            ),
            SizedBox(
              height: 16.h,
            ),
            CustomInputField(
              hintText:
                  'e.g.\nbc691db1e197914c7c0097ad6513efb6a2d68a5aad46afacf8800ffdeab91576',
              height: 56.h,
              inputType: InputType.password,
              capitalizeSentences: false,
              width: double.infinity,
              controller: keyController,
              onEditingComplete: (_) => checkButton,
              onChangedCallback: checkButton,
            ),
            const Expanded(child: SizedBox()),
            SecondaryButton(
              text: 'Or Scan A QR Code',
              width: 1.sw - (2 * 24.w),
              height: 56.h,
              showBorders: false,
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            SizedBox(
              height: 16.h,
            ),
            PrimaryButton(
              text: 'Create An Account',
              width: 1.sw - (2 * 24.w),
              height: 56.h,
              disabled: !buttonEnabled,
              greyOut: !buttonEnabled,
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            SizedBox(
              height:
                  MediaQuery.of(context).viewInsets.bottom > 100 ? 16.h : 50.h,
            ),
          ],
        ),
      ),
    );
  }
}
