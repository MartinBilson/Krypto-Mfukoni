import 'package:air_crypto/style/style.dart';
import 'package:air_crypto/widgets/primary_button.dart';
import 'package:air_crypto/widgets/secondary_button.dart';
import 'package:air_crypto/widgets/switch.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SecurityAndPrivacy extends StatefulWidget {
  const SecurityAndPrivacy({Key? key}) : super(key: key);

  @override
  _SecurityAndPrivacyState createState() => _SecurityAndPrivacyState();
}

class _SecurityAndPrivacyState extends State<SecurityAndPrivacy> {
  bool signInWithAuthHardware = true;
  bool privacyMode = true;
  bool metaMetrics = false;
  bool incomingTransactions = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: Container(
        width: 1.sw,
        padding: EdgeInsets.symmetric(
          horizontal: 24.w,
        ),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 8.h,
              ),
              Center(
                child: Container(
                  height: 6.h,
                  width: 48.w,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6.r),
                    color: const Color(0xFFE0E0E0),
                  ),
                ),
              ),
              SizedBox(
                height: 32.h,
              ),
              Text(
                'Security',
                style: bold,
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Protect your wallet',
                style: regular,
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Protect your wallet by saving your seed phrase in various places like on a air of paper, password manager and/or the cloud',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 12.h),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(
                      'assets/svg/seed_back_up.svg',
                      width: 24.h,
                      height: 24.h,
                    ),
                    SizedBox(
                      width: 8.w,
                    ),
                    Text(
                      'Seed phrase backed up',
                      style: regular.copyWith(fontSize: 14.sp),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 48.h,
                    padding: EdgeInsets.symmetric(horizontal: 14.5.w),
                    decoration: BoxDecoration(
                        color: const Color(0xFFFEF0D7),
                        borderRadius: BorderRadius.circular(48.r)),
                    child: Center(
                      child: Text(
                        'Backup Again',
                        style: bold.copyWith(
                          fontSize: 16.sp,
                          color: AppColors.themeColor,
                        ),
                      ),
                    ),
                  ),
                  PrimaryButton(
                    text: 'Reveal Seed Phrase',
                    width: 178.w,
                    height: 48.h,
                    onPressed: () {},
                  ),
                ],
              ),
              SizedBox(
                height: 24.h,
              ),
              Text('Password', style: regular),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Choose the amount of time before the application automatically locks',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              SecondaryButton(
                text: 'Change Password',
                width: double.infinity,
                height: 48.h,
                onPressed: () {},
              ),
              SizedBox(
                height: 24.h,
              ),
              Text('Auto-lock', style: regular),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Choose the amount of time before the application automatically locks',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'After 30 seconds',
                      style: bold.copyWith(fontSize: 14.sp),
                    ),
                    SvgPicture.asset(
                      'assets/svg/arrow_down.svg',
                      height: 24.h,
                      width: 24.h,
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Sign in with Biometrics?',
                    style: regular.copyWith(
                      fontSize: 18.sp,
                    ),
                  ),
                  CustomSwitch(
                    value: signInWithAuthHardware,
                    activeColor: AppColors.themeColor,
                    onChanged: (value) {
                      setState(() {
                        signInWithAuthHardware = value;
                      });
                    },
                  ),
                ],
              ),
              SizedBox(
                height: 24.h,
              ),
              Text('Show private key for "Queen Bee"', style: regular),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'This is the private key for the current selected account: Account1. Never disclose this key. Anyone with your private key can fully control your account, including transferring away any of your funds.',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 48.h,
              ),
              Text(
                'Privacy',
                style: bold,
              ),
              SizedBox(
                height: 16.h,
              ),
              Text('Clear Privacy Data', style: regular),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Clear Priacy data so all websites must request access to view account information again',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              SecondaryButton(
                text: 'Clear Privacy Data',
                width: double.infinity,
                height: 48.h,
                onPressed: () {},
                disabled: true,
              ),
              SizedBox(
                height: 24.h,
              ),
              Text('Clear Browser History', style: regular),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Choose this option to clear your entire browsing history',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              SecondaryButton(
                text: 'Clear Browser History',
                width: double.infinity,
                height: 48.h,
                onPressed: () {},
              ),
              SizedBox(
                height: 24.h,
              ),
              Text('Clear Browser Cookies', style: regular),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Choose this option to clear your entire browerr’s cookies',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              SecondaryButton(
                text: 'Clear Privacy Data',
                width: double.infinity,
                height: 48.h,
                onPressed: () {},
              ),
              SizedBox(
                height: 24.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Privacy Mode',
                    style: regular.copyWith(
                      fontSize: 18.sp,
                    ),
                  ),
                  CustomSwitch(
                    value: privacyMode,
                    activeColor: AppColors.themeColor,
                    onChanged: (value) {
                      setState(() {
                        privacyMode = value;
                      });
                    },
                  ),
                ],
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Website must request access to view your account information',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Participate in MetaMetrics',
                    style: regular.copyWith(
                      fontSize: 18.sp,
                    ),
                  ),
                  CustomSwitch(
                    value: metaMetrics,
                    activeColor: AppColors.themeColor,
                    onChanged: (value) {
                      setState(() {
                        metaMetrics = value;
                      });
                    },
                  ),
                ],
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Participate in MetaMetrics to help us make Ahrvo better',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Get Incoming Transactions',
                    style: regular.copyWith(
                      fontSize: 18.sp,
                    ),
                  ),
                  CustomSwitch(
                    value: incomingTransactions,
                    activeColor: AppColors.themeColor,
                    onChanged: (value) {
                      setState(() {
                        incomingTransactions = value;
                      });
                    },
                  ),
                ],
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Third party APIs (Etherscan are used to show your incoming transactions in the history. Turn off if you don’t want us to pull data from those service',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 50.h,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
