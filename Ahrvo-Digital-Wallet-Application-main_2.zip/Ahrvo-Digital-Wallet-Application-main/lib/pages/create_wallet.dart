import 'dart:math';
import 'dart:ui';

import 'package:air_crypto/blocs/main_bloc.dart';
import 'package:air_crypto/pages/home.dart';
import 'package:air_crypto/style/style.dart';
import 'package:air_crypto/widgets/input_field.dart';
import 'package:air_crypto/widgets/primary_button.dart';
import 'package:air_crypto/widgets/secondary_button.dart';
import 'package:air_crypto/widgets/switch.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:password_strength/password_strength.dart';
import 'package:provider/provider.dart';

class CreateWallet extends StatefulWidget {
  const CreateWallet({Key? key}) : super(key: key);

  static const routeName = '/createWallet';

  @override
  _CreateWalletState createState() => _CreateWalletState();
}

class _CreateWalletState extends State<CreateWallet> {
  int currStep = 1;
  int secureYourWalletStep = 1;
  int confirmSeedPhraseStep = 1;
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  bool hasPasswordError = false;
  bool hasConfirmPasswordError = false;
  bool signInWithAuthHardware = true;
  bool checkBoxVal = true;
  bool hideSeedPhrase = true;

  double? newPasswordStrength;

  final seedPhrase = [
    'then',
    'vacant',
    'girl',
    'exist',
    'avoid',
    'usage',
    'ride',
    'alien',
    'comic',
    'cross',
    'upon',
    'hub',
  ];

  List randomSeedPhrases = [];

  List selectedConfirmSeedPhrases = [];


  final nameController = TextEditingController();
  bool enteredName = false;
  bool buttonEnabled = false;



  void getRandomPhrasesFromSeedPhrase() {
    while (randomSeedPhrases.length != 3) {
      final _random = Random();
      final element = seedPhrase[_random.nextInt(seedPhrase.length)];
      if (!randomSeedPhrases.contains(element)) {
        randomSeedPhrases.add(element);
      }
    }
  }

  void validatePassword(String pass) {
    newPasswordStrength = estimatePasswordStrength(pass);
    setState(() {
      if (pass.isEmpty) {
        hasPasswordError = true;
      } else if (pass.length < 8) {
        hasPasswordError = true;
      } else {
        hasPasswordError = false;
      }
    });
  }

  void validateConfirmPassword(String pass) {
    setState(() {
      if (pass != newPasswordController.value.text) {
        hasConfirmPasswordError = true;
      } else {
        hasConfirmPasswordError = false;
      }
    });
  }

  Future<void> showSeedPairInfo() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          Container(
            // height: 516.h,
            width: 1.sw,
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFD6D6D6),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Text(
                  "What is a 'Seed phrase'",
                  style: bold.copyWith(fontSize: 18.sp),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Text(
                  'A seed phrase is a set of twelve words that contains all the information about your wallet, including your funds. It\'s like a secret code used to access your entire wallet.\n\nYou must keep your seed phrase secret and safe. If someone gets your seed phrase, they\'ll gain control over your accounts.\n\nSave it in a place where only you can access it. If you lose it, not even Ahrvo can help you recover it.',
                  style: regular.copyWith(
                    fontSize: 16.sp,
                    color: AppColors.grayColor,
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                PrimaryButton(
                  text: 'I Got It',
                  width: 1.sw - (2 * 24.w),
                  height: 56.h,
                  onPressed: () {
                    Navigator.of(context).pop();
                    setState(() {
                      secureYourWalletStep = 2;
                    });
                  },
                ),
                SizedBox(
                  height: 50.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showRemindMeLaterBottomSheet() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          Container(
            // height: 516.h,
            width: 1.sw,
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFD6D6D6),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Text(
                  'Skip Account Security?',
                  style: bold.copyWith(fontSize: 18.sp),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Row(
                  children: [
                    Checkbox(
                      activeColor: AppColors.themeColor,
                      value: checkBoxVal,
                      onChanged: (val) {
                        setState(() {
                          checkBoxVal = val!;
                        });
                      },
                    ),
                    Flexible(
                      child: Text(
                        'I understand that if I lose my seed phrase I will not be able to access my wallet',
                        style: regular.copyWith(
                          fontSize: 14.sp,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 24.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SecondaryButton(
                      text: 'Secure Now',
                      width: 156.w,
                      height: 56.h,
                      onPressed: () {},
                    ),
                    PrimaryButton(
                      text: 'Skip',
                      width: 156.w,
                      height: 56.h,
                      onPressed: () {},
                    ),
                  ],
                ),
                SizedBox(
                  height: 50.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showProtectYourWalletBottomSheet() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          Container(
            width: 1.sw,
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFD6D6D6),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Text(
                  'Protect Your Wallet',
                  style: bold.copyWith(fontSize: 18.sp),
                ),
                SizedBox(
                  height: 26.h,
                ),
                Text(
                  'Dont’t risk losing your funds. Protect your wallet by saving your seed phrase in a place you trust.\n\nIt’s the only way to recover your wallet if you get locked out of the app or get a new device.',
                  style: regular.copyWith(
                    fontSize: 16.sp,
                    color: AppColors.grayColor,
                  ),
                ),
                SizedBox(
                  height: 24.h,
                ),
                PrimaryButton(
                  text: 'I Got It',
                  width: 1.sw - (2 * 24.w),
                  height: 56.h,
                  onPressed: () {
                    Navigator.of(context).pop();
                    setState(() {
                      secureYourWalletStep = 3;
                    });
                  },
                ),
                SizedBox(
                  height: 50.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mb = context.watch<MainBloc>();
    // currStep = 2;
    final progressBarWidth = 271.w;
    return WillPopScope(
      onWillPop: () async {
        if (currStep == 2) {
          if (secureYourWalletStep != 1) {
            setState(() {
              secureYourWalletStep -= 1;
            });
          } else {
            setState(() {
              currStep -= 1;
            });
          }
          return false;
        } else if (currStep == 3) {
          if (confirmSeedPhraseStep != 1) {
            setState(() {
              confirmSeedPhraseStep -= 1;
            });
          } else {
            setState(() {
              currStep -= 1;
            });
          }
          return false;
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: AppColors.backgroundColor,
        body: SingleChildScrollView(
          child: SizedBox(
            width: 1.sw,
            height: 1.sh,
            child: Column(
              children: [
                SizedBox(
                  height: 44.h < ScreenUtil().statusBarHeight
                      ? ScreenUtil().statusBarHeight
                      : 44.h,
                ),
                SizedBox(
                  height: 44.h,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      GestureDetector(
                        onTap: () {
                          if (currStep == 1) {
                            Navigator.of(context).pop();
                          } else if (currStep == 2) {
                            if (secureYourWalletStep != 1) {
                              setState(() {
                                secureYourWalletStep -= 1;
                              });
                            } else {
                              setState(() {
                                currStep -= 1;
                              });
                            }
                          } else if (currStep == 3) {
                            if (confirmSeedPhraseStep != 1) {
                              setState(() {
                                confirmSeedPhraseStep -= 1;
                              });
                            } else {
                              setState(() {
                                currStep -= 1;
                              });
                            }
                          }
                        },
                        child: SvgPicture.asset(
                          currStep == 1
                              ? 'assets/svg/close.svg'
                              : 'assets/svg/arrow_left.svg',
                          height: 24.h,
                          fit: BoxFit.fitHeight,
                          color: AppColors.darkGrayColor,
                        ),
                      ),
                      Container(
                        width: progressBarWidth,
                        height: 8.h,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.r),
                          color: AppColors.lightGrayColor,
                        ),
                        child: Row(
                          children: [
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 500),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8.r),
                                color: AppColors.darkGrayColor,
                              ),
                              height: 8.h,
                              width: currStep == 1
                                  ? progressBarWidth / 3
                                  : currStep == 2
                                      ? (progressBarWidth / 3) * 2
                                      : progressBarWidth,
                            )
                          ],
                        ),
                      ),
                      Text(
                        '$currStep/3',
                        style: bold.copyWith(
                          fontSize: 12.sp,
                          color: AppColors.themeColor,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                if (currStep == 1) ...[
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: SizedBox(
                      width: 1.sw - (2 * 24.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Create Password',
                            style: bold.copyWith(
                              fontSize: 18.sp,
                              color: AppColors.darkGrayColor,
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Text(
                            'This password will unlock your Ahrvo wallet only on this service',
                            style: regular.copyWith(
                              fontSize: 16.sp,
                              color: AppColors.grayColor,
                            ),
                          ),
                          SizedBox(
                            height: 24.h,
                          ),
                          CustomInputField(
                            hintText: 'User name',
                            height: 56.h,
                            inputType: InputType.name,
                            capitalizeSentences: true,
                            width: double.infinity,
                            controller: nameController,
                          ),
                          SizedBox(
                            height: 4.h,
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 16.w,
                              ),
                              Text.rich(
                                TextSpan(
                                  text: 'Enter your user name ',
                                  style: regular.copyWith(
                                    color: AppColors.textFieldBottomTextColor,
                                    fontSize: 12.sp,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 24.h,
                          ),
                          CustomInputField(
                            hintText: 'New password',
                            height: 56.h,
                            width: double.infinity,
                            controller: newPasswordController,
                            hasNextTextField: true,
                            onEditingComplete: validatePassword,
                            onChangedCallback: () => validatePassword(
                                newPasswordController.value.text),
                            hasError: hasPasswordError,
                          ),
                          SizedBox(
                            height: 4.h,
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 16.w,
                              ),
                              Text.rich(
                                TextSpan(
                                  text: 'Password strength: ',
                                  style: regular.copyWith(
                                    color: AppColors.textFieldBottomTextColor,
                                    fontSize: 12.sp,
                                  ),
                                  children: newPasswordStrength != null
                                      ? [
                                    TextSpan(
                                      text: newPasswordStrength! < 0.3
                                          ? 'Weak'
                                          : newPasswordStrength! < 0.7
                                          ? 'Moderate'
                                          : 'Good',
                                      style: regular.copyWith(
                                        color: newPasswordStrength! < 0.3
                                            ? AppColors.errorColor
                                            : newPasswordStrength! < 0.7
                                            ? Colors.amber[700]
                                            : AppColors.greenColor,
                                        fontSize: 12.sp,
                                      ),
                                    ),
                                  ]
                                      : null,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 18.h,
                          ),
                          CustomInputField(
                            hintText: 'Confirm password',
                            height: 56.h,
                            width: double.infinity,
                            controller: confirmPasswordController,
                            onEditingComplete: validateConfirmPassword,
                            onChangedCallback: () => validateConfirmPassword(
                              confirmPasswordController.value.text,
                            ),
                            hasError: hasConfirmPasswordError,
                          ),
                          SizedBox(
                            height: 4.h,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 16.w),
                            child: Text(
                              'Must be at least 8 characters',
                              style: regular.copyWith(
                                fontSize: 12.sp,
                                color: hasPasswordError
                                    ? AppColors.errorColor
                                    : AppColors.textFieldBottomTextColor,
                              ),
                            ),
                          ),
                          if (hasConfirmPasswordError)
                            Padding(
                              padding: EdgeInsets.only(left: 16.w),
                              child: Text(
                                'Passwords don\'t match',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.errorColor,
                                ),
                              ),
                            ),
                          SizedBox(
                            height: 16.h,
                          ),
                          if (mb.hasFaceID || mb.hasTouchID)
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  // 'Sign in with ${Platform.isIOS ? mb.hasFaceID ? 'Face ID' : mb.hasTouchID ? 'Touch ID' : '' : mb.hasFaceID ? 'Face ID' : mb.hasTouchID ? 'Fingerprint' : ''}?',
                                  'Sign in with Biometrics?',
                                  style: regular.copyWith(
                                    fontSize: 18.sp,
                                  ),
                                ),
                                CustomSwitch(
                                  value: signInWithAuthHardware,
                                  activeColor: AppColors.themeColor,
                                  onChanged: (value) {
                                    setState(() {
                                      signInWithAuthHardware = value;
                                    });
                                  },
                                ),
                              ],
                            ),
                          SizedBox(
                            height: 24.h,
                          ),
                          Row(
                            children: [
                              Checkbox(
                                activeColor: AppColors.themeColor,
                                value: checkBoxVal,
                                onChanged: (val) {
                                  setState(() {
                                    checkBoxVal = val!;
                                  });
                                },
                              ),
                              Flexible(
                                child: Text.rich(
                                  TextSpan(
                                    text:
                                        'I understand that Ahrvo cannot recover this password for me. ',
                                    style: regular.copyWith(
                                      fontSize: 14.sp,
                                    ),
                                    children: [
                                      TextSpan(
                                        text: 'Learn more',
                                        style: bold.copyWith(
                                          color: const Color(0xFF4C70D0),
                                          fontSize: 14.sp,
                                          decoration: TextDecoration.underline,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Expanded(child: SizedBox()),
                  PrimaryButton(
                    text: 'Create Password',
                    width: 1.sw - (2 * 24.w),
                    height: 56.h,
                    onPressed: () {
                      validatePassword(newPasswordController.value.text);
                      validateConfirmPassword(
                          confirmPasswordController.value.text);
                      if (hasConfirmPasswordError || hasPasswordError) return;
                      setState(() {
                        currStep = 2;
                      });
                    },
                  ),
                ],
                if (currStep == 2 && secureYourWalletStep == 1) ...[
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: SizedBox(
                      width: 1.sw - (2 * 24.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Secure your wallet',
                            style: bold.copyWith(
                              fontSize: 18.sp,
                              color: AppColors.darkGrayColor,
                            ),
                          ),
                          SizedBox(
                            height: 56.h,
                          ),
                          Center(
                            child: Image.asset(
                              // 'assets/images/secure_your_wallet.png',
                              'assets/images/icon_transparent.png',
                              height: 198.35.h,
                              fit: BoxFit.cover,
                            ),
                          ),
                          SizedBox(
                            height: 61.65.h,
                          ),
                          Text.rich(
                            TextSpan(
                              text:
                                  'Don\'t risk losing your funds. protect your wallet by saving your ',
                              style: regular.copyWith(
                                fontSize: 16.sp,
                                color: AppColors.grayColor,
                              ),
                              children: [
                                TextSpan(
                                  text: 'seed phrase',
                                  style: bold.copyWith(
                                    fontSize: 16.sp,
                                    color: AppColors.themeColor,
                                  ),
                                ),
                                TextSpan(
                                  text: ' in a place you trust. ',
                                  style: regular.copyWith(
                                    fontSize: 16.sp,
                                    color: AppColors.grayColor,
                                  ),
                                ),
                                TextSpan(
                                  text:
                                      'It\'s the only way to recover your wallet if you get locked out of the app or get a new device.',
                                  style: regular.copyWith(
                                    fontSize: 16.sp,
                                    color: AppColors.textColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Expanded(child: SizedBox()),
                  SecondaryButton(
                    text: 'Remind Me Later',
                    width: 1.sw - (2 * 24.w),
                    height: 56.h,
                    showBorders: false,
                    onPressed: showRemindMeLaterBottomSheet,
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  PrimaryButton(
                    text: 'Start',
                    width: 1.sw - (2 * 24.w),
                    height: 56.h,
                    onPressed: showSeedPairInfo,
                  ),
                ],
                if (currStep == 2 && secureYourWalletStep == 2) ...[
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: SizedBox(
                      width: 1.sw - (2 * 24.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Secure your wallet',
                            style: bold.copyWith(
                              fontSize: 18.sp,
                              color: AppColors.darkGrayColor,
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Text.rich(
                            TextSpan(
                              text: 'Secure your wallet\'s ',
                              style: regular.copyWith(
                                fontSize: 16.sp,
                                color: AppColors.textColor,
                              ),
                              children: [
                                TextSpan(
                                  text: 'seed phrase',
                                  style: bold.copyWith(
                                    fontSize: 16.sp,
                                    color: AppColors.themeColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Row(
                            children: [
                              SvgPicture.asset(
                                'assets/svg/help.svg',
                                height: 24.h,
                                fit: BoxFit.cover,
                              ),
                              SizedBox(
                                width: 8.w,
                              ),
                              Text(
                                'Why is it important?',
                                style: bold.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.blueHyperlinkColor,
                                  decoration: TextDecoration.underline,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Container(
                            width: 1.sw - (2 * 24.w),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              color: Colors.white,
                            ),
                            padding:
                                EdgeInsets.fromLTRB(16.w, 16.w, 16.w, 24.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Write down your seed phrase on a piece of paper and store in a safe place.',
                                  style: regular.copyWith(
                                    fontSize: 14.sp,
                                    color: AppColors.grayColor,
                                  ),
                                ),
                                SizedBox(
                                  height: 12.h,
                                ),
                                Text.rich(
                                  TextSpan(
                                    text: 'Security level: ',
                                    style: regular.copyWith(
                                      fontSize: 14.sp,
                                      color: AppColors.grayColor,
                                    ),
                                    children: [
                                      TextSpan(
                                        text: 'Very Strong: ',
                                        style: regular.copyWith(
                                          fontSize: 14.sp,
                                          color: AppColors.blueHyperlinkColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 12.h,
                                ),
                                Row(
                                  children: [
                                    Container(
                                      height: 8.h,
                                      width: 32.w,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(8.r),
                                        color: AppColors.greenColor,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 8.w,
                                    ),
                                    Container(
                                      height: 8.h,
                                      width: 32.w,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(8.r),
                                        color: AppColors.greenColor,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 8.w,
                                    ),
                                    Container(
                                      height: 8.h,
                                      width: 32.w,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(8.r),
                                        color: AppColors.greenColor,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 8.w,
                                    ),
                                    Container(
                                      height: 8.h,
                                      width: 32.w,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(8.r),
                                        color: AppColors.greenColor,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 16.h,
                                ),
                                Text(
                                  'Risks are: \n• You lose it\n• You forget where you put it\n• Someone else finds it',
                                  style: regular.copyWith(
                                    fontSize: 14.sp,
                                    color: AppColors.grayColor,
                                  ),
                                ),
                                SizedBox(
                                  height: 16.h,
                                ),
                                Text(
                                  'Other options: Doesn\'t have to be paper!',
                                  style: regular.copyWith(
                                    fontSize: 14.sp,
                                    color: AppColors.grayColor,
                                  ),
                                ),
                                SizedBox(
                                  height: 16.h,
                                ),
                                Text(
                                  'Tips:\n• Store in bank vault\n• Store in a safe\n• Store in multiple secret places',
                                  style: regular.copyWith(
                                    fontSize: 14.sp,
                                    color: AppColors.grayColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Expanded(child: SizedBox()),
                  PrimaryButton(
                    text: 'Start',
                    width: 1.sw - (2 * 24.w),
                    height: 56.h,
                    onPressed: showProtectYourWalletBottomSheet,
                  ),
                ],
                if (currStep == 2 && secureYourWalletStep == 3) ...[
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: SizedBox(
                      width: 1.sw - (2 * 24.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Write Down Your Seed Phrase',
                            style: bold.copyWith(
                              fontSize: 18.sp,
                              color: AppColors.darkGrayColor,
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Text(
                            'This is your seed phrase. Write it down on a paper and keep it in a safe place. You\'ll be asked to re-enter this phrase (in order) on the next step.',
                            style: regular.copyWith(
                              fontSize: 16.sp,
                              color: AppColors.grayColor,
                            ),
                          ),
                          SizedBox(
                            height: 32.h,
                          ),
                          Stack(
                            children: [
                              Container(
                                width: 1.sw - (24.w * 2),
                                padding: EdgeInsets.only(
                                  left: 16.w,
                                  right: 16.w,
                                  top: 16.w,
                                  bottom: 24.w,
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    width: 1,
                                    color: AppColors.lightGrayColor,
                                  ),
                                ),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '1. ${seedPhrase[0]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '2. ${seedPhrase[1]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '3. ${seedPhrase[2]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '4. ${seedPhrase[3]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '5. ${seedPhrase[4]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '6. ${seedPhrase[5]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '7. ${seedPhrase[6]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '8. ${seedPhrase[7]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '9. ${seedPhrase[8]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '10. ${seedPhrase[9]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '11. ${seedPhrase[10]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 88.w,
                                          height: 40.h,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(40.r),
                                          ),
                                          child: Center(
                                            child: FittedBox(
                                              child: Text(
                                                '12. ${seedPhrase[11]}',
                                                style: regular.copyWith(
                                                  color: AppColors.textColor,
                                                  fontSize: 14.sp,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              if (hideSeedPhrase)
                                GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      hideSeedPhrase = false;
                                    });
                                  },
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(16),
                                    child: BackdropFilter(
                                      filter: ImageFilter.blur(
                                          sigmaX: 4, sigmaY: 4),
                                      child: Container(
                                        width: 1.sw - (24.w * 2),
                                        height: 248.h + 2,
                                        padding: EdgeInsets.symmetric(
                                            vertical: 66.h),
                                        color: Colors.black.withOpacity(0.6),
                                        child: Column(
                                          children: [
                                            SvgPicture.asset(
                                              'assets/svg/eye_hidden.svg',
                                              color: Colors.white,
                                              height: 40.h,
                                            ),
                                            SizedBox(
                                              height: 16.h,
                                            ),
                                            Text(
                                              'Tap to reveal your seed phrase',
                                              style: bold.copyWith(
                                                fontSize: 18.sp,
                                                color: Colors.white,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 8.h,
                                            ),
                                            Text(
                                              'Make sure no one is watching your screen.',
                                              style: regular.copyWith(
                                                fontSize: 14.sp,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Expanded(child: SizedBox()),
                  PrimaryButton(
                    text: 'Continue',
                    width: 1.sw - (2 * 24.w),
                    height: 56.h,
                    onPressed: () {
                      randomSeedPhrases = [];
                      getRandomPhrasesFromSeedPhrase();
                      setState(() {
                        currStep = 3;
                      });
                    },
                    greyOut: hideSeedPhrase,
                  ),
                ],
                if (currStep == 3 && confirmSeedPhraseStep == 1) ...[
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: SizedBox(
                      width: 1.sw - (2 * 24.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Confirm Seed Phrase',
                            style: bold.copyWith(
                              fontSize: 18.sp,
                              color: AppColors.darkGrayColor,
                            ),
                          ),
                          SizedBox(
                            height: 24.h,
                          ),
                          Container(
                            width: 1.sw - (24.w * 2),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              color: Colors.white,
                            ),
                            padding:
                                EdgeInsets.fromLTRB(16.w, 16.h, 16.w, 32.h),
                            child: Column(
                              children: [
                                Text(
                                  'Select each word in the order it was presented to you',
                                  style: regular.copyWith(
                                    fontSize: 16.sp,
                                    color: AppColors.darkGrayColor,
                                  ),
                                ),
                                SizedBox(
                                  height: 24.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: randomSeedPhrases
                                      .map(
                                        (phrase) => selectedConfirmSeedPhrases
                                                .contains(phrase)
                                            ? Container(
                                                width: 88.w,
                                                height: 40.h,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                    40.r,
                                                  ),
                                                  color:
                                                      AppColors.lightGreenColor,
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    phrase,
                                                    style: regular.copyWith(
                                                      fontSize: 14.sp,
                                                      color:
                                                          AppColors.greenColor,
                                                    ),
                                                  ),
                                                ),
                                              )
                                            : DottedBorder(
                                                padding: EdgeInsets.zero,
                                                strokeWidth: 3,
                                                dashPattern: const [6, 3],
                                                color: const Color(0xFFE0E0E0),
                                                borderType: BorderType.RRect,
                                                radius: Radius.circular(40.r),
                                                child: Container(
                                                  width: 88.w,
                                                  height: 40.h,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            40.r),
                                                    color: Colors.white,
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      seedPhrase
                                                          .indexOf(phrase)
                                                          .toString(),
                                                      style: regular.copyWith(
                                                          fontSize: 14.sp,
                                                          color: AppColors
                                                              .textColor),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                      )
                                      .toList(),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 32.h,
                          ),
                          Container(
                            width: 1.sw - (24.w * 2),
                            padding: EdgeInsets.only(
                              left: 16.w,
                              right: 16.w,
                              top: 16.w,
                              bottom: 24.w,
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                width: 1,
                                color: AppColors.lightGrayColor,
                              ),
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[0],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[1],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[2],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 16.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[3],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[4],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[5],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 16.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[6],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[7],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[8],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 16.h,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[9],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[10],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 88.w,
                                      height: 40.h,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: FittedBox(
                                          child: Text(
                                            seedPhrase[11],
                                            style: regular.copyWith(
                                              color: AppColors.textColor,
                                              fontSize: 14.sp,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Expanded(child: SizedBox()),
                  PrimaryButton(
                    text: 'Continue',
                    width: 1.sw - (2 * 24.w),
                    height: 56.h,
                    onPressed: () {
                      setState(() {
                        confirmSeedPhraseStep = 2;
                      });
                    },
                    greyOut: hideSeedPhrase,
                  ),
                ],
                if (currStep == 3 && confirmSeedPhraseStep == 2) ...[
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: SizedBox(
                      width: 1.sw - (2 * 24.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Image.asset(
                              // 'assets/images/confirm_done.png',
                              'assets/images/icon_transparent.png',
                              height: 198.35.h,
                              fit: BoxFit.cover,
                            ),
                          ),
                          SizedBox(
                            height: 14.65.h,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 16.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Congratulations',
                                  style: bold.copyWith(
                                    fontSize: 18.sp,
                                  ),
                                ),
                                SizedBox(
                                  height: 8.h,
                                ),
                                Text.rich(
                                  TextSpan(
                                    text:
                                        'you\'ve successfully protected your wallet.\nRemember to keep your seed phrase safe, it\'s your responsibility!\n\n\n',
                                    style: regular.copyWith(
                                      color: AppColors.grayColor,
                                      fontSize: 14.sp,
                                    ),
                                    children: [
                                      TextSpan(
                                        text: 'Leave yourself a hint?\n\n\n',
                                        style: bold.copyWith(
                                          color: AppColors.blueHyperlinkColor,
                                          fontSize: 16.sp,
                                          decoration: TextDecoration.underline,
                                        ),
                                      ),
                                      TextSpan(
                                        text:
                                            'Ahrvo cannot recover your wallet should you lose it. You can find your seedphrase in\n',
                                        style: regular.copyWith(
                                          color: AppColors.grayColor,
                                          fontSize: 14.sp,
                                        ),
                                      ),
                                      TextSpan(
                                        text:
                                            'Setting > Security & Privacy\n\n\n',
                                        style: bold.copyWith(
                                          color: AppColors.darkGrayColor,
                                          fontSize: 14.sp,
                                        ),
                                      ),
                                      TextSpan(
                                        text: 'Learn more?',
                                        style: bold.copyWith(
                                          color: AppColors.blueHyperlinkColor,
                                          fontSize: 16.sp,
                                          decoration: TextDecoration.underline,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Expanded(child: SizedBox()),
                  PrimaryButton(
                    text: 'Continue',
                    width: 1.sw - (2 * 24.w),
                    height: 56.h,
                    onPressed: () {
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          Home.routeName, (route) => false);
                    },
                    greyOut: hideSeedPhrase,
                  ),
                ],
                SizedBox(
                  height: 50.h,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
