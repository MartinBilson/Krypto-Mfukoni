import 'package:air_crypto/pages/send_tokens.dart';
import 'package:air_crypto/style/style.dart';
import 'package:air_crypto/utils/utils.dart';
import 'package:air_crypto/widgets/primary_button.dart';
import 'package:air_crypto/widgets/secondary_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

class TokenDetails extends StatelessWidget {
  const TokenDetails({
    Key? key,
    required this.cryptoAmmount,
    required this.cryptoName,
    required this.dollarAmmount,
    required this.upPercent,
  }) : super(key: key);
  final String cryptoName;
  final String cryptoAmmount;
  final String dollarAmmount;
  final String upPercent;

  @override
  Widget build(BuildContext context) {
    final height = 1.sh;
    final width = 1.sw;

    return Scaffold(
      body: SizedBox(
        width: width,
        height: height,
        child: Stack(
          children: [
            // Positioned(
            //   top: 0,
            //   right: -30.w,
            //   child: Image.asset(
            //     'assets/images/home_top_right.png',
            //     width: 151.w,
            //     height: 184.h,
            //   ),
            // ),
            SizedBox(
              width: width,
              height: height,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 44.h,
                  ),
                  SizedBox(
                    height: 44.h,
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: 16.w,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: Navigator.of(context).pop,
                            child: SvgPicture.asset(
                              'assets/svg/arrow_left.svg',
                              height: 24.h,
                              fit: BoxFit.fitHeight,
                              color: AppColors.darkGrayColor,
                            ),
                          ),
                          Text(
                            cryptoName,
                            style: bold.copyWith(
                              fontSize: 18.sp,
                              color: AppColors.textColor,
                            ),
                          ),
                          SizedBox(
                            width: 24.h,
                            height: 24.h,
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  Center(
                    child: Padding(
                      // padding: EdgeInsets.only(left: 24.w),
                      padding: EdgeInsets.zero,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        // crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTap: null,
                            child: Container(
                              height: 40.h,
                              width: 40.h,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: AppColors.lightGrayColor,
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTap: null,
                            child: Text(
                              cryptoAmmount,
                              style: regular.copyWith(
                                fontSize: 34.sp,
                                color: AppColors.textColor,
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 8.h,
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                dollarAmmount,
                                style: regular.copyWith(
                                  fontSize: 20.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              SizedBox(
                                width: 16.w,
                              ),
                              SvgPicture.asset(
                                'assets/svg/green_arrow_up_tilted.svg',
                                height: 16.h,
                                width: 16.h,
                              ),
                              SizedBox(
                                width: 4.w,
                              ),
                              Text(
                                upPercent,
                                style: regular.copyWith(
                                  fontSize: 20.sp,
                                  color: AppColors.greenColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        GestureDetector(
                          onTap: () => showCupertinoModalBottomSheet(
                            context: context,
                            builder: (context) => const SendTokens(),
                          ).then(
                            (value) {
                              console('Back');
                              if (value != null && value) {
                                showTokenSubmitted(context);
                              }
                            },
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SvgPicture.asset(
                                'assets/svg/send.svg',
                                width: 40.h,
                                height: 40.h,
                              ),
                              Text(
                                'Send',
                                style: bold.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.textColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => showReceive(context),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SvgPicture.asset(
                                'assets/svg/receive.svg',
                                width: 40.h,
                                height: 40.h,
                              ),
                              Text(
                                'Receive',
                                style: bold.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.textColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 40.h,
                          height: 40.h,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  SizedBox(
                    height: 0.55 * height,
                    child: ListView(
                      physics: const BouncingScrollPhysics(),
                      padding: EdgeInsets.symmetric(horizontal: 24.w),
                      children: [
                        TransactionCard(
                          cryptoAmmount: '2.8 BNB',
                          cryptoName: cryptoName,
                          dollarAmmount: '\$647.22',
                          transactionStatus: TransactionStatus.pending,
                          transactionType: TransactionType.received,
                          dateAndTime: 'Mar 4 at 10:04 AM',
                        ),
                        SizedBox(
                          height: 12.h,
                        ),
                        TransactionCard(
                          cryptoAmmount: '1.334 BNB',
                          cryptoName: cryptoName,
                          dollarAmmount: '\$315.34426',
                          transactionStatus: TransactionStatus.failed,
                          transactionType: TransactionType.sent,
                          dateAndTime: '#1 Mar 3 at 12:08 AM',
                        ),
                        SizedBox(
                          height: 12.h,
                        ),
                        TransactionCard(
                          cryptoAmmount: '2.891 BNB',
                          cryptoName: cryptoName,
                          dollarAmmount: '\$683403.49',
                          transactionStatus: TransactionStatus.confirmed,
                          transactionType: TransactionType.sent,
                          dateAndTime: '#1 Mar 3 at 12:08 AM',
                        ),
                        SizedBox(
                          height: 12.h,
                        ),
                        TransactionCard(
                          cryptoAmmount: '0.5637 BNB',
                          cryptoName: cryptoName,
                          dollarAmmount: '\$133,2530',
                          transactionStatus: TransactionStatus.confirmed,
                          transactionType: TransactionType.received,
                          dateAndTime: '#1 Mar 3 at 12:08 AM',
                        ),
                        SizedBox(
                          height: 12.h,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> showReceive(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          SizedBox(
            width: 1.sw,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 8.h,
                  ),
                  Center(
                    child: Container(
                      height: 6.h,
                      width: 48.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6.r),
                        color: const Color(0xFFD6D6D6),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 32.h,
                  ),
                  Text(
                    'Received BNB',
                    style: bold.copyWith(fontSize: 18.sp),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: Container(
                      height: 279.h,
                      width: 279.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: AppColors.grayColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Center(
                    child: Text(
                      'Scan address to Receive payment',
                      style: regular.copyWith(
                        fontSize: 16.sp,
                        color: AppColors.grayColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 16.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SecondaryButton(
                        height: 56.h,
                        width: 155.w,
                        onPressed: Navigator.of(context).pop,
                        text: 'bc1q87...34pm',
                        textStyle: bold.copyWith(
                          fontSize: 14.sp,
                          color: AppColors.themeColor,
                        ),
                        icon: SvgPicture.asset(
                          'assets/svg/copy.svg',
                          width: 24.h,
                          height: 24.h,
                        ),
                      ),
                      SecondaryButton(
                        height: 56.h,
                        width: 155.w,
                        onPressed: Navigator.of(context).pop,
                        text: 'Share',
                        textStyle: bold.copyWith(
                          fontSize: 14.sp,
                          color: AppColors.themeColor,
                        ),
                        icon: SvgPicture.asset(
                          'assets/svg/share.svg',
                          width: 24.h,
                          height: 24.h,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  PrimaryButton(
                    icon: SvgPicture.asset(
                      'assets/svg/arrow_up.svg',
                      width: 24.h,
                      height: 24.h,
                    ),
                    text: 'Send Link',
                    width: double.infinity,
                    height: 56.h,
                    onPressed: () {},
                  ),
                  SizedBox(
                    height: 50.h,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showTokenSubmitted(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          SizedBox(
            width: 1.sw,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFD6D6D6),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Text(
                    'Send BNB',
                    style: bold.copyWith(fontSize: 18.sp),
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Center(
                  child: SvgPicture.asset(
                    'assets/svg/submitted.svg',
                    width: 64.h,
                    height: 64.h,
                    fit: BoxFit.cover,
                  ),
                ),
                Center(
                  child: Text(
                    'Submitted',
                    style: bold.copyWith(
                      fontSize: 18.sp,
                      color: AppColors.textColor,
                    ),
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 24.h),
                    width: 1.sw - (2 * 24.w),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: Colors.white,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Amount',
                                style: regular,
                              ),
                              Text(
                                '2.3686 BNB',
                                style: regular,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 4.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Network fee',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                '0.972 BNB',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        const Divider(
                          color: Color(0xFFDADADA),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'From',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                'bc1q87...34pm',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'To',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                '3g78pk...sd42',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Date',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                'Feb 28 at 2:03 PM',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Nonce',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                '#0',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        const Divider(
                          color: Color(0xFFDADADA),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Total Amount',
                                style: regular,
                              ),
                              Text(
                                '3.3406 BNB',
                                style: bold,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                '\$ 880.05',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 42.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SecondaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: () => showCancel(context),
                        showBorders: false,
                        text: 'Cancel',
                      ),
                      PrimaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: () => showSpeedUp(context),
                        text: 'Speed Up',
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 50.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showSpeedUp(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          SizedBox(
            width: 1.sw,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 8.h,
                  ),
                  Center(
                    child: Container(
                      height: 6.h,
                      width: 48.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6.r),
                        color: const Color(0xFFD6D6D6),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 32.h,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: Text(
                      'Attempt to speed up?',
                      style: bold.copyWith(fontSize: 18.sp),
                    ),
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Gas Speed Up Fee',
                        style: regular,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 4.h),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30.r),
                        ),
                        child: Center(
                          child: Text(
                            '<0.00001 ETH',
                            style: bold.copyWith(
                              fontSize: 14.sp,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Text(
                    'Submitting this attempt does not guarantee your original transaction will be accelerated. If the speed up attempt is successful, you will be charged the transaction fee above.',
                    style: regular.copyWith(
                      fontSize: 16.sp,
                      color: AppColors.grayColor,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SecondaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: Navigator.of(context).pop,
                        showBorders: false,
                        text: 'Nevermind',
                      ),
                      PrimaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: Navigator.of(context).pop,
                        text: 'Yes, Let\'s Try',
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 50.h,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showCancel(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          SizedBox(
            width: 1.sw,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 8.h,
                  ),
                  Center(
                    child: Container(
                      height: 6.h,
                      width: 48.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6.r),
                        color: const Color(0xFFD6D6D6),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 32.h,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: Text(
                      'Attempt to cancel?',
                      style: bold.copyWith(fontSize: 18.sp),
                    ),
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Gas Cancellation Fee',
                        style: regular,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 4.h),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30.r),
                        ),
                        child: Center(
                          child: Text(
                            '<0.00001 ETH',
                            style: bold.copyWith(
                              fontSize: 14.sp,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 24.h,
                  ),
                  Text(
                    'Submitting this attempt does not guarantee your original transaction will be cancelled. If the cancellation attempt is successful, you will be charged the transaction fee above.',
                    style: regular.copyWith(
                      fontSize: 16.sp,
                      color: AppColors.grayColor,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SecondaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: Navigator.of(context).pop,
                        showBorders: false,
                        text: 'Nevermind',
                      ),
                      PrimaryButton(
                        height: 56.h,
                        width: 156.w,
                        onPressed: Navigator.of(context).pop,
                        text: 'Yes, Let\'s Try',
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 50.h,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

enum TransactionType {
  received,
  sent,
}

enum TransactionStatus {
  pending,
  confirmed,
  failed,
}

class TransactionCard extends StatefulWidget {
  const TransactionCard({
    Key? key,
    required this.cryptoAmmount,
    required this.cryptoName,
    required this.dollarAmmount,
    required this.transactionStatus,
    required this.transactionType,
    required this.dateAndTime,
  }) : super(key: key);
  final String dateAndTime;
  final String cryptoName;
  final String cryptoAmmount;
  final String dollarAmmount;
  final TransactionType transactionType;
  final TransactionStatus transactionStatus;

  @override
  State<TransactionCard> createState() => _TransactionCardState();
}

class _TransactionCardState extends State<TransactionCard> {
  Future<void> showTransactionDetails() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          SizedBox(
            width: 1.sw,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFD6D6D6),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Text(
                    'Received ${widget.cryptoName}',
                    style: bold.copyWith(fontSize: 18.sp),
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Center(
                  child: SvgPicture.asset(
                    'assets/svg/confirmed.svg',
                    width: 64.h,
                    height: 64.h,
                    fit: BoxFit.cover,
                  ),
                ),
                Center(
                  child: Text(
                    'Confirmed',
                    style: bold.copyWith(
                      fontSize: 18.sp,
                      color: AppColors.textColor,
                    ),
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 24.h),
                    width: 1.sw - (2 * 24.w),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: Colors.white,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Amount',
                                style: regular,
                              ),
                              Text(
                                '0.5637 BNB',
                                style: regular,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 4.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                '\$133,2530',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        const Divider(
                          color: Color(0xFFDADADA),
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'From',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                'bc1q87...34pm',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'To',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                '3g78pk...sd42',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Date',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                'Feb 28 at 2:03 PM',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Nonce',
                                style: regular.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.grayColor,
                                ),
                              ),
                              Text(
                                '#0',
                                style: regular.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: SecondaryButton(
                    height: 56.h,
                    width: 1.sw - (2 * 24.w),
                    onPressed: () {},
                    showBorders: false,
                    text: 'View On Mainnet',
                  ),
                ),
                SizedBox(
                  height: 50.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        showTransactionDetails();
        if (widget.transactionStatus == TransactionStatus.confirmed) {
          // ! Show confirmed dialog
        } else {
          // ! Show failed dialog
        }
      },
      child: Container(
        width: double.infinity,
        height: 96.h,
        padding: EdgeInsets.only(top: 8.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.white,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 24.w),
              child: Text(
                widget.dateAndTime,
                style: regular.copyWith(
                  fontSize: 12.sp,
                  color: AppColors.grayColor,
                ),
              ),
            ),
            SizedBox(
              height: 4.h,
            ),
            Expanded(
              child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.w),
                    child: Row(
                      children: [
                        SvgPicture.asset(
                          widget.transactionStatus == TransactionStatus.pending
                              ? 'assets/svg/pending.svg'
                              : widget.transactionStatus ==
                                      TransactionStatus.failed
                                  ? 'assets/svg/sent_failed.svg'
                                  : widget.transactionType ==
                                          TransactionType.sent
                                      ? 'assets/svg/sent_confirmed.svg'
                                      : 'assets/svg/received_confirmed.svg',
                          width: 40.h,
                          height: 40.h,
                        ),
                        SizedBox(
                          width: 8.w,
                        ),
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    '${widget.transactionType == TransactionType.received ? 'Received' : 'Send'} ${widget.cryptoName}',
                                    style: regular.copyWith(
                                      fontSize: 18.sp,
                                      color: AppColors.textColor,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 5.h,
                                  ),
                                  Text(
                                    widget.transactionStatus ==
                                            TransactionStatus.pending
                                        ? 'Pending'
                                        : widget.transactionStatus ==
                                                TransactionStatus.confirmed
                                            ? 'Confirmed'
                                            : 'Failed',
                                    style: bold.copyWith(
                                      fontSize: 12.sp,
                                      color: widget.transactionStatus ==
                                              TransactionStatus.pending
                                          ? AppColors.yellowColor
                                          : widget.transactionStatus ==
                                                  TransactionStatus.confirmed
                                              ? AppColors.greenColor
                                              : AppColors.redColor,
                                    ),
                                  ),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    widget.cryptoAmmount,
                                    style: regular.copyWith(
                                      fontSize: 18.sp,
                                      color: AppColors.textColor,
                                    ),
                                  ),
                                  Text(
                                    widget.dollarAmmount,
                                    style: regular.copyWith(
                                      fontSize: 16.sp,
                                      color: AppColors.grayColor,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
