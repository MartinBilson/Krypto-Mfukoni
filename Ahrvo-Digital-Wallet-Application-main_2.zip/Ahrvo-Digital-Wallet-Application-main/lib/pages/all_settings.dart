import 'dart:ui';

import 'package:air_crypto/pages/general_settings.dart';
import 'package:air_crypto/pages/security_and_privacy.dart';
import 'package:air_crypto/style/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

class AllSettings extends StatelessWidget {
  const AllSettings({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: SizedBox(
        width: 1.sw,
        height: 1.sh,
        child: Stack(
          children: [
            // Positioned(
            //   top: 211.h,
            //   right: 0,
            //   child: Image.asset(
            //     'assets/images/all_settings_pyramid.png',
            //     fit: BoxFit.cover,
            //     height: 210.h,
            //   ),
            // ),
            // Positioned(
            //   top: 470.h,
            //   left: 0,
            //   child: Image.asset(
            //     'assets/images/all_settings_cube.png',
            //     fit: BoxFit.cover,
            //     height: 180.h,
            //   ),
            // ),
            Column(
              children: [
                SizedBox(
                  height: 52.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: Navigator.of(context).pop,
                        child: SvgPicture.asset(
                          'assets/svg/arrow_left.svg',
                          height: 24.h,
                          width: 24.h,
                        ),
                      ),
                      Text(
                        'Setting',
                        style: bold,
                      ),
                      SizedBox(
                        width: 24.h,
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 24.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      renderSettingTile(
                        title: 'General',
                        description:
                            'Currency conversion, primary currency, language and search engine',
                        onPress: () {
                          showCupertinoModalBottomSheet(
                            builder: (context) => const GeneralSettings(),
                            context: context,
                          );
                        },
                      ),
                      SizedBox(
                        height: 12.h,
                      ),
                      renderSettingTile(
                        title: 'Security & Privacy',
                        description:
                            'Privacy settings, MetaMetrics, private key and wallet seed phrase',
                        onPress: () {
                          showCupertinoModalBottomSheet(
                            builder: (context) => const SecurityAndPrivacy(),
                            context: context,
                          );
                        },
                      ),
                      SizedBox(
                        height: 12.h,
                      ),
                      renderSettingTile(
                        title: 'Advanced',
                        description:
                            'Access developer features, reset account, setup testnets, sync extension, state logs,...',
                        onPress: () {},
                      ),
                      SizedBox(
                        height: 12.h,
                      ),
                      renderSettingTile(
                        title: 'Contacts',
                        description:
                            'Add, edit, remove, and manage your accounts',
                        onPress: () {},
                      ),
                      SizedBox(
                        height: 12.h,
                      ),
                      renderSettingTile(
                        title: 'Networks',
                        description: 'Add and edit custom RPC networks',
                        onPress: () {},
                      ),
                      SizedBox(
                        height: 12.h,
                      ),
                      renderSettingTile(
                        title: 'Experimental',
                        description: 'About Ahrvo',
                        onPress: () {},
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget renderSettingTile({
    required String title,
    required String description,
    required VoidCallback onPress,
  }) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: onPress,
      child: Container(
        width: double.infinity,
        height: 86.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
              color: Colors.white.withOpacity(0.10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: 263.w,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          title,
                          style: regular.copyWith(fontSize: 16.sp),
                        ),
                        Text(
                          description,
                          style: regular.copyWith(
                            fontSize: 12.sp,
                            color: AppColors.grayColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SvgPicture.asset(
                    'assets/svg/arrow_right.svg',
                    height: 24.h,
                    width: 24.h,
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
