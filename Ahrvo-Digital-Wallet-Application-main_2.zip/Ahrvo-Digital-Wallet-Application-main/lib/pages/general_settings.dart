import 'package:air_crypto/style/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

enum Currency { native, fiat }

class GeneralSettings extends StatefulWidget {
  const GeneralSettings({Key? key}) : super(key: key);

  @override
  _GeneralSettingsState createState() => _GeneralSettingsState();
}

class _GeneralSettingsState extends State<GeneralSettings> {
  Currency currencyVal = Currency.native;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: Container(
        width: 1.sw,
        padding: EdgeInsets.symmetric(
          horizontal: 24.w,
        ),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 8.h,
              ),
              Center(
                child: Container(
                  height: 6.h,
                  width: 48.w,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6.r),
                    color: const Color(0xFFE0E0E0),
                  ),
                ),
              ),
              SizedBox(
                height: 32.h,
              ),
              Text(
                'General',
                style: bold,
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Title',
                style: regular,
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'content',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Base Currency',
                          style: regular.copyWith(
                            fontSize: 12.sp,
                            color: AppColors.textFieldHintTextColor,
                          ),
                        ),
                        Text(
                          'USD - United State Dollar',
                          style: bold.copyWith(
                            fontSize: 14.sp,
                          ),
                        ),
                      ],
                    ),
                    SvgPicture.asset(
                      'assets/svg/arrow_down.svg',
                      height: 24.h,
                      width: 24.h,
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Text(
                'Privacy Currency',
                style: regular,
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Select Native to prioritize displaying values in the native currency of the chain (e.g. ETH). Select Fiat to prioritize displaying values in your selected fiat currency',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Row(
                children: [
                  Radio<Currency>(
                    activeColor: AppColors.themeColor,
                    groupValue: currencyVal,
                    value: Currency.native,
                    onChanged: (value) {
                      setState(() {
                        currencyVal = value!;
                      });
                    },
                  ),
                  Text(
                    'Native',
                    style: regular.copyWith(
                      fontSize: 16.sp,
                    ),
                  ),
                  SizedBox(
                    width: 70.w,
                  ),
                  Radio<Currency>(
                    activeColor: AppColors.themeColor,
                    groupValue: currencyVal,
                    value: Currency.fiat,
                    onChanged: (value) {
                      setState(() {
                        currencyVal = value!;
                      });
                    },
                  ),
                  Text(
                    'Fiat',
                    style: regular.copyWith(
                      fontSize: 16.sp,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 24.h,
              ),
              Text(
                'Current Language',
                style: regular,
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Translate the application to a different supported language',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Language',
                          style: regular.copyWith(
                            fontSize: 12.sp,
                            color: AppColors.textFieldHintTextColor,
                          ),
                        ),
                        Text(
                          'English',
                          style: bold.copyWith(
                            fontSize: 14.sp,
                          ),
                        ),
                      ],
                    ),
                    SvgPicture.asset(
                      'assets/svg/arrow_down.svg',
                      height: 24.h,
                      width: 24.h,
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Text(
                'Search Engine',
                style: regular,
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Change the default search engine used when entering search terms in the URL bar',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Engine',
                          style: regular.copyWith(
                            fontSize: 12.sp,
                            color: AppColors.textFieldHintTextColor,
                          ),
                        ),
                        Text(
                          'DuckDuckGo',
                          style: bold.copyWith(
                            fontSize: 14.sp,
                          ),
                        ),
                      ],
                    ),
                    SvgPicture.asset(
                      'assets/svg/arrow_down.svg',
                      height: 24.h,
                      width: 24.h,
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Text(
                'Account Identicon',
                style: regular,
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'You can customize your account',
                style: regular.copyWith(
                  fontSize: 16.sp,
                  color: AppColors.grayColor,
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 16.h),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Custom Account',
                      style: regular,
                    ),
                    SvgPicture.asset(
                      'assets/svg/arrow_down.svg',
                      height: 24.h,
                      width: 24.h,
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 90.h,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
