import 'package:air_crypto/pages/create_wallet.dart';
import 'package:air_crypto/pages/import_wallet.dart';
import 'package:air_crypto/style/style.dart';
import 'package:air_crypto/widgets/primary_button.dart';
import 'package:air_crypto/widgets/secondary_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

class WalletSetup extends StatelessWidget {
  const WalletSetup({Key? key}) : super(key: key);
  static const routeName = '/walletSetup';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: SizedBox(
        width: 1.sw,
        height: 1.sh,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                height: 130.h,
              ),
              Center(
                child: Image.asset(
                  // 'assets/images/wallet_setup.png',
                  'assets/images/icon_transparent.png',
                  // width: 280.w,
                  height: 220.h,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(
                height: 66.7.h,
              ),
              Text(
                'Wallet Setup',
                style: regular.copyWith(
                  fontSize: 46.sp,
                  color: AppColors.themeColor,

                ),

              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                'Import an existing wallet\nor create a new one',
                textAlign: TextAlign.center,
                style: regular.copyWith(
                  color: AppColors.themeColor,
                ),
              ),
              const Expanded(
                child: SizedBox(),
              ),
              Center(
                child: SecondaryButton(
                  text: 'Import Using Seed Phrase',
                  width: 327.w,
                  height: 56.h,
                  onPressed: () {
                    showCupertinoModalBottomSheet(
                      context: context,
                      builder: (context) => const ImportWallet(),
                    );
                  },
                ),
              ),
              SizedBox(
                height: 16.w,
              ),
              Center(
                child: PrimaryButton(
                  text: 'Create A New Wallet',
                  width: 327.w,
                  height: 56.h,
                  onPressed: () =>
                      Navigator.of(context).pushNamed(CreateWallet.routeName),
                ),
              ),
              SizedBox(
                height: 50.h,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
