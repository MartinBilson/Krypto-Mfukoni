import 'package:air_crypto/style/style.dart';
import 'package:air_crypto/widgets/input_field.dart';
import 'package:air_crypto/widgets/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'home.dart';

class SendTokens extends StatefulWidget {
  const SendTokens({Key? key}) : super(key: key);

  @override
  _SendTokensState createState() => _SendTokensState();
}

class _SendTokensState extends State<SendTokens> {
  bool showRecent = true;
  int currStep = 1;
  final addressController = TextEditingController();
  final balanceController = TextEditingController();

  Future<void> showAccounts() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
          bottom: Radius.circular(16),
        ),
      ),
      builder: (context) => Wrap(
        children: [
          Container(
            width: 1.sw,
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 8.h,
                ),
                Center(
                  child: Container(
                    height: 6.h,
                    width: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xFFD6D6D6),
                    ),
                  ),
                ),
                SizedBox(
                  height: 32.h,
                ),
                Text(
                  'Account',
                  style: bold.copyWith(fontSize: 18.sp),
                ),
                SizedBox(
                  height: 24.h,
                ),
                const AccountTile(
                  emojiBgColor: Color(0xFFFEF0D7),
                  emoji: '🐼',
                  title: 'Queen Bee',
                  isSelected: true,
                ),
                SizedBox(
                  height: 32.h,
                ),
                const AccountTile(
                  emojiBgColor: Color(0xFFFFEBDD),
                  emoji: '🐋',
                  title: 'Lalimo Rubik',
                  isSelected: false,
                ),
                SizedBox(
                  height: 32.h,
                ),
                const AccountTile(
                  emojiBgColor: Color(0xFFEBEBEB),
                  emoji: '🐇',
                  title: 'Neil momo',
                  isSelected: false,
                ),
                SizedBox(
                  height: 24.h,
                ),
                SizedBox(
                  height: 50.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: Container(
        width: 1.sw,
        padding: EdgeInsets.symmetric(
            horizontal: currStep == 1 || currStep == 3 ? 24.w : 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 8.h,
            ),
            Center(
              child: Container(
                height: 6.h,
                width: 48.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6.r),
                  color: const Color(0xFFE0E0E0),
                ),
              ),
            ),
            SizedBox(
              height: 32.h,
            ),
            if (currStep == 1) ...[
              Text(
                'Send Tokens',
                style: bold,
              ),
              SizedBox(
                height: 24.h,
              ),
              GestureDetector(
                onTap: showAccounts,
                child: Container(
                  width: double.infinity,
                  height: 64.h,
                  padding: EdgeInsets.symmetric(horizontal: 16.w),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            height: 40.h,
                            width: 40.h,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColors.pandaBgColor,
                            ),
                            child: Center(
                              child: Text(
                                '🐼',
                                style: bold.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 8.w,
                          ),
                          Text(
                            'Queen Bee',
                            style: bold.copyWith(
                              fontSize: 12.sp,
                              color: AppColors.themeColor,
                            ),
                          ),
                        ],
                      ),
                      SvgPicture.asset(
                        'assets/svg/arrow_down.svg',
                        width: 24.h,
                        height: 24.h,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: 8.w),
                      child: Text(
                        'To',
                        style: bold.copyWith(
                          fontSize: 16.sp,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 4.h,
                    ),
                    CustomInputField(
                      controller: addressController,
                      width: double.infinity,
                      height: 56.h,
                      hintText: 'Search, public address (0x), or ENS',
                      showScanIcon: showRecent,
                      onScanPress: () {},
                      onChangedCallback: () {
                        if (addressController.value.text.trim().isNotEmpty) {
                          if (showRecent) {
                            setState(() {
                              showRecent = false;
                            });
                          }
                        } else if (!showRecent) {
                          setState(() {
                            showRecent = true;
                          });
                        }
                      },
                      inputType: InputType.name,
                    ),
                    if (showRecent) ...[
                      SizedBox(
                        height: 24.h,
                      ),
                      Center(
                        child: Text(
                          'Transfer Between My Accounts',
                          style: bold.copyWith(
                            fontSize: 14.sp,
                            color: AppColors.blueHyperlinkColor,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 8.h,
                      ),
                    ]
                  ],
                ),
              ),
              if (showRecent) ...[
                SizedBox(
                  height: 24.h,
                ),
                Text(
                  'Recent',
                  style: bold,
                ),
                SizedBox(
                  height: 16.h,
                ),
                renderRecentCard(
                  name: 'Jennie',
                  address: '0x3Dc6...DxE9',
                  emoji: '🐇',
                  emojiBgColor: const Color(0xFFEBEBEB),
                ),
                SizedBox(
                  height: 12.h,
                ),
                renderRecentCard(
                  name: 'Das Cra',
                  address: '0x2Dc6...DcT9',
                  emoji: '🐋',
                  emojiBgColor: const Color(0xFFFFEBDD),
                ),
                SizedBox(
                  height: 12.h,
                ),
                renderRecentCard(
                  name: 'Gevan',
                  address: '0x3R2E...DxR9',
                  emoji: '🦄',
                  emojiBgColor: const Color(0xFFE7FFDD),
                ),
              ],
              if (!showRecent) ...[
                const Expanded(
                  child: SizedBox(),
                ),
                PrimaryButton(
                  text: 'Next',
                  width: double.infinity,
                  height: 56.h,
                  onPressed: () {
                    setState(() {
                      currStep = 2;
                    });
                  },
                ),
                SizedBox(
                  height: MediaQuery.of(context).viewInsets.bottom > 100
                      ? 16.h
                      : 50.h,
                ),
              ],
            ],
            if (currStep == 2) ...[
              GestureDetector(
                onTap: () {
                  setState(() {
                    currStep = 1;
                  });
                },
                child: Padding(
                  padding: EdgeInsets.only(left: 16.w),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        'assets/svg/arrow_left.svg',
                        width: 24.h,
                        height: 24.h,
                      ),
                      SizedBox(
                        width: 8.w,
                      ),
                      Text(
                        'Amount',
                        style: bold,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 18.h,
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 24.w),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: 89.w,
                    ),
                    Container(
                      width: 94.w,
                      height: 40.h,
                      padding:
                          EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40.r),
                        border: Border.all(
                          color: AppColors.themeColor,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'BNB',
                            style: bold.copyWith(
                              fontSize: 14.sp,
                              color: AppColors.themeColor,
                            ),
                          ),
                          SvgPicture.asset(
                            'assets/svg/arrow_down.svg',
                            width: 24.w,
                            height: 24.w,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 89.w,
                      height: 40.h,
                      child: Center(
                        child: Text(
                          'Use max',
                          style: bold.copyWith(
                            fontSize: 14.sp,
                            color: AppColors.themeColor,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 32.h,
              ),
              TextField(
                autofocus: true,
                autocorrect: false,
                showCursor: true,
                readOnly: true,
                cursorColor: AppColors.themeColor,
                textAlign: TextAlign.center,
                controller: balanceController,
                style: regular.copyWith(
                  fontSize: 48.sp,
                ),
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  errorBorder: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                ),
              ),
              Center(
                child: Container(
                  height: 40.h,
                  width: 121.w,
                  padding:
                      EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40.r),
                    color: AppColors.lightGrayColor,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '\$ 488.40',
                        style: regular.copyWith(
                          fontSize: 14.sp,
                        ),
                      ),
                      SvgPicture.asset(
                        'assets/svg/convert.svg',
                        height: 24.w,
                        width: 24.w,
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 12.h,
              ),
              Center(
                child: Text(
                  'Balance: 11.4188 BNB',
                  style: regular.copyWith(
                    fontSize: 14.sp,
                    color: AppColors.grayColor,
                  ),
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              Wrap(
                alignment: WrapAlignment.start,
                spacing: 9.w,
                direction: Axis.horizontal,
                children: [
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '1';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '1',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '2';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '2',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '3';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '3',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '4';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '4',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '5';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '5',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '6';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '6',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '7';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '7',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '8';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '8',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '9';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '9',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '.';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '.',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      setState(() {
                        balanceController.text =
                            balanceController.value.text + '0';
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: Text(
                          '0',
                          style: regular.copyWith(
                            fontSize: 24.sp,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {
                      if (balanceController.value.text.isEmpty) return;
                      setState(() {
                        balanceController.text = balanceController.value.text
                            .substring(
                                0, balanceController.value.text.length - 1);
                        balanceController.selection =
                            TextSelection.fromPosition(TextPosition(
                                offset: balanceController.text.length));
                      });
                    },
                    child: SizedBox(
                      height: 68.h,
                      width: 119.w,
                      child: Center(
                        child: SvgPicture.asset(
                          'assets/svg/backspace.svg',
                          width: 24.w,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const Expanded(
                child: SizedBox(),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 24.w),
                child: PrimaryButton(
                  text: 'Next',
                  width: double.infinity,
                  height: 56.h,
                  onPressed: () {
                    setState(() {
                      currStep = 3;
                    });
                  },
                  disabled: balanceController.value.text.isEmpty,
                  greyOut: balanceController.value.text.isEmpty,
                ),
              ),
              SizedBox(
                height: 50.h,
              ),
            ],
            if (currStep == 3) ...[
              GestureDetector(
                onTap: () {
                  setState(() {
                    currStep = 2;
                  });
                },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SvgPicture.asset(
                      'assets/svg/arrow_left.svg',
                      width: 24.h,
                      height: 24.h,
                    ),
                    SizedBox(
                      width: 8.w,
                    ),
                    Text(
                      'Confirm',
                      style: bold,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              GestureDetector(
                onTap: showAccounts,
                child: Container(
                  width: double.infinity,
                  height: 64.h,
                  padding: EdgeInsets.symmetric(horizontal: 16.w),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            height: 40.h,
                            width: 40.h,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColors.pandaBgColor,
                            ),
                            child: Center(
                              child: Text(
                                '🐼',
                                style: bold.copyWith(
                                  fontSize: 16.sp,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 8.w,
                          ),
                          Text(
                            'Queen Bee',
                            style: bold.copyWith(
                              fontSize: 12.sp,
                              color: AppColors.themeColor,
                            ),
                          ),
                        ],
                      ),
                      SvgPicture.asset(
                        'assets/svg/arrow_down.svg',
                        width: 24.h,
                        height: 24.h,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: 8.w),
                      child: Text(
                        'To',
                        style: bold.copyWith(
                          fontSize: 16.sp,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 4.h,
                    ),
                    CustomInputField(
                      controller: addressController,
                      width: double.infinity,
                      height: 56.h,
                      hintText: 'Search, public address (0x), or ENS',
                      showScanIcon: showRecent,
                      onScanPress: () {},
                      disabled: true,
                      onChangedCallback: () {
                        if (addressController.value.text.trim().isNotEmpty) {
                          if (showRecent) {
                            setState(() {
                              showRecent = false;
                            });
                          }
                        } else if (!showRecent) {
                          setState(() {
                            showRecent = true;
                          });
                        }
                      },
                      inputType: InputType.name,
                    ),
                    SizedBox(
                      height: 8.h,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Container(
                padding: EdgeInsets.symmetric(vertical: 24.h),
                width: 1.sw - (2 * 24.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 24.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Amount',
                            style: regular,
                          ),
                          Text(
                            '2.3686 BNB',
                            style: regular,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 4.h,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 24.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Network fee',
                            style: regular.copyWith(
                              fontSize: 16.sp,
                              color: AppColors.grayColor,
                            ),
                          ),
                          Text(
                            '0.972 BNB',
                            style: regular.copyWith(
                              fontSize: 16.sp,
                              color: AppColors.grayColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 24.h,
                    ),
                    const Divider(
                      color: Color(0xFFDADADA),
                    ),
                    SizedBox(
                      height: 24.h,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 24.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Total Amount',
                            style: regular,
                          ),
                          Text(
                            '3.3406 BNB',
                            style: bold,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 16.h,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 24.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(
                            '\$ 880.05',
                            style: regular.copyWith(
                              fontSize: 16.sp,
                              color: AppColors.grayColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const Expanded(
                child: SizedBox(),
              ),
              PrimaryButton(
                text: 'Send',
                width: double.infinity,
                height: 56.h,
                onPressed: () {
                  Navigator.of(context).pop(true);
                  // Future.delayed(
                  //   const Duration(milliseconds: 500),
                  // ).then(
                  //   (value) => showTokenSubmitted(),
                  // );
                },
              ),
              SizedBox(
                height: MediaQuery.of(context).viewInsets.bottom > 100
                    ? 16.h
                    : 50.h,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Container renderRecentCard({
    required String emoji,
    required Color emojiBgColor,
    required String name,
    required String address,
  }) {
    return Container(
      width: double.infinity,
      height: 78.h,
      padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 16.w),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.white,
      ),
      child: Row(
        children: [
          Container(
            width: 40.h,
            height: 40.h,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: emojiBgColor,
            ),
            child: Center(
              child: Text(
                emoji,
                style: bold.copyWith(
                  fontSize: 16.sp,
                ),
              ),
            ),
          ),
          SizedBox(
            width: 8.w,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                name,
                style: regular,
              ),
              Text(
                address,
                style: regular.copyWith(
                  fontSize: 14.sp,
                  color: AppColors.grayColor,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
