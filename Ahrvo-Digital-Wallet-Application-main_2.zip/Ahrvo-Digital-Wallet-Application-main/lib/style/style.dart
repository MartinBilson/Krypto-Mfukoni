import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppColors {
  static const backgroundColor = Color(0xFFFAFAFA);
  static const themeColor = Color(0xFF1A2853);
  static const textColor = Color(0xFF0A0A0A);
  static const whiteTextColor = Color(0xFFFFFFFF);
  static const grayColor = Color(0xFF858585);
  static const lightGrayColor = Color(0xFFF5F5F5);
  static const greenColor = Color(0xFF53AE57);
  static const yellowColor = Color(0xFFFFC548);
  static const redColor = Color(0xFFFF6655);
  static const lightGreenColor = Color(0xFFE8FAE0);
  static const darkGrayColor = Color(0xFF0A0A0A);
  static const blueHyperlinkColor = Color(0xFF4C70D0);

  static const tabbarColor = Color(0xFFF38337);
  static const pandaBgColor = Color(0xFFDCE8FC);

  static const textFieldBottomTextColor = Color(0xFFADADAD);
  static const selectedTextFieldBorderColor = Color(0xFF0A0A0A);
  static const errorColor = Color(0xFFFF6655);
  static const textFieldBorderColor = lightGrayColor;
  static const textFieldHintTextColor = Color(0xFFB8B8B8);
}

final regular = TextStyle(
  // fontFamily: 'Red Hat Display',
  fontFamily: 'Nunito',
  fontSize: 18.sp,
  color: AppColors.textColor,
);

final bold = TextStyle(
  // fontFamily: 'Red Hat Display',
  fontFamily: 'Nunito',
  fontSize: 18.sp,
  fontWeight: FontWeight.bold,
  color: AppColors.textColor,
);
