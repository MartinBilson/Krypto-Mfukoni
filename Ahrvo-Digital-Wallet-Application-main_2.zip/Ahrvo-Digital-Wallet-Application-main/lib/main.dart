import 'package:air_crypto/blocs/main_bloc.dart';
import 'package:air_crypto/pages/create_wallet.dart';
import 'package:air_crypto/pages/home.dart';
import 'package:air_crypto/pages/swap.dart';
import 'package:air_crypto/pages/transaction_history.dart';
import 'package:air_crypto/pages/wallet_setup.dart';
import 'package:air_crypto/style/style.dart';
import 'package:air_crypto/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:provider/provider.dart';

// ! TODO


void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => MainBloc(),
      builder: (context, child) => const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    context.read<MainBloc>().checkSupportedAuthHardware();
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      builder: () => MaterialApp(
        onGenerateRoute: (settings) {
          return MaterialWithModalsPageRoute(
            settings: settings,
            builder: (context) {
              if (settings.name == WalletSetup.routeName) {
                return const WalletSetup();
              }
              if (settings.name == CreateWallet.routeName) {
                return const CreateWallet();
              }
              if (settings.name == Home.routeName) {
                return const Home();
              }
              if (settings.name == SwapScreen.routeName) {
                return const SwapScreen();
              }
              if (settings.name == TransactionHistory.routeName) {
                return const TransactionHistory();
              }

              warn('Route ${settings.name} NOT FOUND!');
              return Container();
            },
          );
        },
        color: AppColors.backgroundColor,
        title: 'Ahrvo Wallet',
        debugShowCheckedModeBanner: false,
        initialRoute: WalletSetup.routeName,
      ),
    );
  }
}
