import 'package:logger/logger.dart';

var _logger = Logger(
  printer: PrettyPrinter(
    colors: true,
    printEmojis: true,
  ),
);
console(msg) {
  _logger.d(msg);
}

warn(msg) {
  _logger.w(msg);
}

error(msg) {
  _logger.e(msg);
}
