import 'package:air_crypto/style/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SecondaryButton extends StatelessWidget {
  const SecondaryButton({
    Key? key,
    required this.text,
    required this.width,
    required this.height,
    required this.onPressed,
    this.textStyle,
    this.disabled = false,
    this.isLoading = false,
    this.showBorders = true,
    this.icon,
  }) : super(key: key);
  final String text;
  final double width;
  final double height;
  final VoidCallback onPressed;
  final bool disabled;
  final bool isLoading;
  final bool showBorders;
  final Widget? icon;
  final TextStyle? textStyle;

  @override
  Widget build(BuildContext context) {
    const loadingIndicator = CircularProgressIndicator(
      valueColor: AlwaysStoppedAnimation<Color>(
        AppColors.themeColor,
      ),
    );

    return AnimatedContainer(
      duration: const Duration(milliseconds: 500),
      width: isLoading ? height : width,
      child: OutlinedButton(
        onPressed: isLoading || disabled ? null : onPressed,
        child: isLoading
            ? loadingIndicator
            : icon != null
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      icon!,
                      SizedBox(
                        width: 8.w,
                      ),
                      Text(
                        text,
                        maxLines: 1,
                        style: textStyle ??
                            bold.copyWith(
                              fontSize: 16.sp,
                            ),
                      ),
                    ],
                  )
                : Text(
                    text,
                    maxLines: 1,
                    style: textStyle ??
                        bold.copyWith(
                          fontSize: 16.sp,
                        ),
                  ),
        style: OutlinedButton.styleFrom(
          primary: AppColors.themeColor,
          backgroundColor: Colors.transparent,
          minimumSize: isLoading ? Size(height, height) : Size(width, height),
          padding: const EdgeInsets.all(0),
          side: showBorders
              ? const BorderSide(
                  width: 1,
                  color: AppColors.themeColor,
                )
              : const BorderSide(
                  width: 0,
                  color: Colors.transparent,
                ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(height.r),
          ),
        ),
      ),
    );
  }
}
