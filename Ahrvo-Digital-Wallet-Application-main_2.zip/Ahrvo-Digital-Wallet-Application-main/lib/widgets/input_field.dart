import 'package:air_crypto/style/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

enum InputType {
  email,
  name,
  password,
}

typedef OnEditingCompleteCallback = void Function(String value);

class CustomInputField extends StatefulWidget {
  const CustomInputField({
    Key? key,
    required this.controller,
    required this.width,
    required this.height,
    required this.hintText,
    this.hasNextTextField = false,
    this.showScanIcon = false,
    this.capitalizeSentences = false,
    this.inputType = InputType.password,
    this.hasError = false,
    this.disabled = false,
    this.isSearch = false,
    this.onChangedCallback,
    this.onScanPress,
    this.onEditingComplete,
  }) : super(key: key);
  final TextEditingController controller;
  final double width;
  final double height;
  final InputType inputType;
  final String hintText;
  final bool hasNextTextField;
  final bool capitalizeSentences;
  final bool hasError;
  final bool disabled;
  final bool showScanIcon;
  final bool isSearch;
  final VoidCallback? onChangedCallback;
  final VoidCallback? onScanPress;
  final OnEditingCompleteCallback? onEditingComplete;

  @override
  State<CustomInputField> createState() => _CustomInputFieldState();
}

class _CustomInputFieldState extends State<CustomInputField> {
  bool hidePass = true;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      width: widget.width,
      height: widget.height,
      child: TextField(
        enabled: !widget.disabled,
        controller: widget.controller,
        cursorColor: AppColors.themeColor,
        decoration: InputDecoration(
          // contentPadding:
          // widget.isSearch ? EdgeInsets.fromLTRB(0, 12, 0, 12) : null,
          prefixIconConstraints: widget.isSearch
              ? BoxConstraints(
                  maxHeight: 24.h,
                  // maxWidth: 24.h,
                )
              : null,
          prefixIcon: widget.isSearch
              ? Padding(
                  padding: EdgeInsets.only(left: 16.w, right: 8.w),
                  child: SvgPicture.asset(
                    'assets/svg/search.svg',
                    height: 24.h,
                    width: 24.h,
                  ),
                )
              : null,
          labelText: !widget.isSearch ? widget.hintText : null,
          labelStyle: bold.copyWith(
            color: AppColors.textFieldHintTextColor,
            fontSize: 12.sp,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(
              width: 1,
              color: AppColors.selectedTextFieldBorderColor,
            ),
          ),
          enabledBorder: widget.hasError
              ? OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(
                    width: 1,
                    color: AppColors.errorColor,
                  ),
                )
              : OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(
                    width: 1,
                    color: AppColors.textFieldBorderColor,
                  ),
                ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(
              width: 1,
              color: AppColors.textFieldBorderColor,
            ),
          ),

          floatingLabelBehavior:
              !widget.isSearch ? FloatingLabelBehavior.auto : null,
          suffixIcon:
              widget.inputType == InputType.password || widget.showScanIcon
                  ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (widget.inputType == InputType.password)
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                hidePass = !hidePass;
                              });
                            },
                            child: Padding(
                              padding: EdgeInsets.only(right: 16.w),
                              child: hidePass
                                  ? SvgPicture.asset(
                                      'assets/svg/eye_visble.svg',
                                      width: 24.h,
                                      height: 24.h,
                                      fit: BoxFit.cover,
                                    )
                                  : SvgPicture.asset(
                                      'assets/svg/eye_hidden.svg',
                                      width: 24.h,
                                      height: 24.h,
                                      fit: BoxFit.cover,
                                    ),
                            ),
                          ),
                        if (widget.showScanIcon)
                          GestureDetector(
                            onTap: widget.onScanPress,
                            child: Padding(
                              padding: EdgeInsets.only(right: 16.w),
                              child: SvgPicture.asset(
                                'assets/svg/scan.svg',
                                width: 24.h,
                                height: 24.h,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                      ],
                    )
                  : null,
          suffixIconConstraints: widget.inputType == InputType.password
              ? BoxConstraints(
                  minHeight: 0,
                  minWidth: 0,
                  maxHeight: 24.h,
                )
              : null,
          hintText: widget.isSearch ? widget.hintText : null,
          hintStyle: widget.isSearch
              ? bold.copyWith(
                  color: AppColors.textFieldHintTextColor,
                  fontSize: 12.sp,
                )
              : null,
        ),
        style: bold.copyWith(
          color: AppColors.textColor,
          fontSize: 14.sp,
        ),
        onSubmitted: widget.onEditingComplete,
        onChanged: widget.onChangedCallback != null
            ? (value) => widget.onChangedCallback!()
            : null,
        textInputAction: widget.hasNextTextField
            ? TextInputAction.next
            : TextInputAction.done,
        obscureText: widget.inputType == InputType.password ? hidePass : false,
        keyboardType: widget.inputType == InputType.email
            ? TextInputType.emailAddress
            : null,
      ),
    );
  }
}
