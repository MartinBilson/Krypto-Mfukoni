import 'package:air_crypto/style/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class PrimaryButton extends StatelessWidget {
  const PrimaryButton({
    Key? key,
    required this.text,
    required this.width,
    required this.height,
    required this.onPressed,
    this.disabled = false,
    this.greyOut = false,
    this.isLoading = false,
    this.icon,
  }) : super(key: key);
  final bool greyOut;
  final String text;
  final double width;
  final double height;
  final VoidCallback onPressed;
  final bool disabled;
  final bool isLoading;
  final Widget? icon;

  @override
  Widget build(BuildContext context) {
    const loadingIndicator = CircularProgressIndicator(
      valueColor: AlwaysStoppedAnimation<Color>(
        AppColors.whiteTextColor,
      ),
    );

    return AnimatedContainer(
      duration: const Duration(milliseconds: 500),
      width: isLoading ? height : width,
      child: TextButton(
        onPressed: greyOut || isLoading || disabled ? null : onPressed,
        child: isLoading
            ? loadingIndicator
            : icon != null
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      icon!,
                      SizedBox(
                        width: 8.w,
                      ),
                      Text(
                        text,
                        maxLines: 1,
                        style: bold.copyWith(
                          fontSize: 16.sp,
                          color: greyOut
                              ? const Color(0xFFE0E0E0)
                              : AppColors.whiteTextColor,
                        ),
                      ),
                    ],
                  )
                : Text(
                    text,
                    maxLines: 1,
                    style: bold.copyWith(
                      fontSize: 16.sp,
                      color: greyOut
                          ? const Color(0xFFE0E0E0)
                          : AppColors.whiteTextColor,
                    ),
                  ),
        style: TextButton.styleFrom(
          primary: AppColors.whiteTextColor,
          backgroundColor:
              greyOut ? AppColors.lightGrayColor : AppColors.themeColor,
          minimumSize: isLoading ? Size(height, height) : Size(width, height),
          padding: const EdgeInsets.all(0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(height.r),
          ),
        ),
      ),
    );
  }
}
